/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // Case Status Colors
        status: {
          new: {
            DEFAULT: '#3b82f6',
            light: '#dbeafe',
            dark: '#1e40af',
          },
          assigned: {
            DEFAULT: '#f59e0b',
            light: '#fef3c7',
            dark: '#b45309',
          },
          in_progress: {
            DEFAULT: '#8b5cf6',
            light: '#ede9fe',
            dark: '#5b21b6',
          },
          pending: {
            DEFAULT: '#f97316',
            light: '#ffedd5',
            dark: '#c2410c',
          },
          resolved: {
            DEFAULT: '#22c55e',
            light: '#dcfce7',
            dark: '#15803d',
          },
          closed: {
            DEFAULT: '#6b7280',
            light: '#f3f4f6',
            dark: '#374151',
          },
        },
        // Priority Colors
        priority: {
          low: {
            DEFAULT: '#10b981',
            light: '#d1fae5',
          },
          medium: {
            DEFAULT: '#f59e0b',
            light: '#fef3c7',
          },
          high: {
            DEFAULT: '#ef4444',
            light: '#fee2e2',
          },
          critical: {
            DEFAULT: '#7c3aed',
            light: '#ede9fe',
          },
        },
        // SLA Colors
        sla: {
          on_track: '#22c55e',
          at_risk: '#f59e0b',
          breached: '#ef4444',
        },
        // Brand Colors
        brand: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'sans-serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.2s ease-in-out',
        'slide-in': 'slideIn 0.3s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideIn: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
}
