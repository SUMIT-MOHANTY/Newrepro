// Define the types
export type CaseStatus = 'NEW' | 'ASSIGNED' | 'IN_PROGRESS' | 'PENDING' | 'RESOLVED' | 'CLOSED'
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'
export type ChannelType = 'EMAIL' | 'CHAT' | 'PHONE' | 'SOCIAL'

// Re-export types for convenience
export type { CaseStatus as CaseStatusType }
export type { Priority as PriorityType }
export type { ChannelType as ChannelTypeType }

// Export interfaces
export interface Agent {
  id: string
  name: string
  email: string
  avatar?: string
  role: 'ADMIN' | 'AGENT' | 'SUPERVISOR'
  status: 'ONLINE' | 'OFFLINE' | 'BUSY' | 'AWAY'
  casesAssigned: number
}

export interface Channel {
  id: string
  name: string
  type: ChannelType
  status: 'ACTIVE' | 'INACTIVE' | 'MAINTENANCE'
  icon: string
  unreadCount: number
}

export interface InboxItem {
  id: string
  subject: string
  sender: string
  senderEmail: string
  preview: string
  receivedAt: string
  isRead: boolean
  isStarred?: boolean
  channel: ChannelType
  hasAttachment: boolean
}

export interface Case {
  id: string
  title: string
  description: string
  status: CaseStatus
  priority: Priority
  customerName: string
  customerEmail: string
  assignedTo?: string
  channel: ChannelType
  createdAt: string
  updatedAt: string
  dueDate?: string
  tags: string[]
}

// Export types explicitly for pages that import them
export type { Case, InboxItem, Channel, Agent }

// Mock Agents
export const mockAgents: Agent[] = [
  {
    id: 'A001',
    name: 'Sarah Chen',
    email: 'sarah.chen@company.com',
    role: 'SUPERVISOR',
    status: 'ONLINE',
    casesAssigned: 12,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
  },
  {
    id: 'A002',
    name: 'Marcus Johnson',
    email: 'marcus.j@company.com',
    role: 'AGENT',
    status: 'BUSY',
    casesAssigned: 8,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Marcus',
  },
  {
    id: 'A003',
    name: 'Emily Rodriguez',
    email: 'emily.r@company.com',
    role: 'AGENT',
    status: 'ONLINE',
    casesAssigned: 6,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Emily',
  },
  {
    id: 'A004',
    name: 'David Kim',
    email: 'david.kim@company.com',
    role: 'ADMIN',
    status: 'AWAY',
    casesAssigned: 3,
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=David',
  },
]

// Mock Channels
export const mockChannels: Channel[] = [
  {
    id: 'CH001',
    name: 'Support Email',
    type: 'EMAIL',
    status: 'ACTIVE',
    icon: 'EnvelopeIcon',
    unreadCount: 23,
  },
  {
    id: 'CH002',
    name: 'Live Chat',
    type: 'CHAT',
    status: 'ACTIVE',
    icon: 'ChatBubbleLeftRightIcon',
    unreadCount: 8,
  },
  {
    id: 'CH003',
    name: 'Phone Support',
    type: 'PHONE',
    status: 'ACTIVE',
    icon: 'PhoneIcon',
    unreadCount: 5,
  },
  {
    id: 'CH004',
    name: 'Social Media',
    type: 'SOCIAL',
    status: 'MAINTENANCE',
    icon: 'GlobeAltIcon',
    unreadCount: 0,
  },
]

// Mock Inbox Items
export const mockInboxItems: InboxItem[] = [
  {
    id: 'IN001',
    subject: 'Urgent: Payment processing issue',
    sender: 'John Smith',
    senderEmail: 'john.smith@customer.com',
    preview: 'Hi, I\'m having trouble processing my payment for order #12345. The system keeps showing an error...',
    receivedAt: '2026-01-15T09:30:00Z',
    isRead: false,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: true,
  },
  {
    id: 'IN002',
    subject: 'Question about product warranty',
    sender: 'Maria Garcia',
    senderEmail: 'maria.g@email.com',
    preview: 'Hello, I purchased a laptop last month and wanted to confirm the warranty coverage...',
    receivedAt: '2026-01-15T08:45:00Z',
    isRead: false,
    isStarred: true,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN003',
    subject: 'Live chat transcript',
    sender: 'Support Bot',
    senderEmail: 'system@company.com',
    preview: 'Chat session with customer #45678 - Issue resolved, agent assigned...',
    receivedAt: '2026-01-15T08:15:00Z',
    isRead: true,
    isStarred: false,
    channel: 'CHAT',
    hasAttachment: false,
  },
  {
    id: 'IN004',
    subject: 'Refund request for order #98765',
    sender: 'Robert Wilson',
    senderEmail: 'rwilson@customer.com',
    preview: 'I would like to request a refund for my recent purchase. The item arrived damaged...',
    receivedAt: '2026-01-15T07:50:00Z',
    isRead: false,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: true,
  },
  {
    id: 'IN005',
    subject: 'Account access problem',
    sender: 'Lisa Anderson',
    senderEmail: 'lisa.a@email.com',
    preview: 'I can\'t log into my account. It says my password is incorrect but I\'m sure it\'s right...',
    receivedAt: '2026-01-15T07:20:00Z',
    isRead: true,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN006',
    subject: 'Feature request: Dark mode',
    sender: 'Tech Enthusiast',
    senderEmail: 'techie@example.com',
    preview: 'Would love to see a dark mode option in the mobile app. It would really help with...',
    receivedAt: '2026-01-14T18:30:00Z',
    isRead: true,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN007',
    subject: 'Billing inquiry - Invoice #INV-2026-001',
    sender: 'Finance Dept',
    senderEmail: 'finance@partner.com',
    preview: 'Please review the attached invoice and confirm the payment terms...',
    receivedAt: '2026-01-14T16:45:00Z',
    isRead: true,
    isStarred: true,
    channel: 'EMAIL',
    hasAttachment: true,
  },
  {
    id: 'IN008',
    subject: 'Integration support needed',
    sender: 'Dev Team Lead',
    senderEmail: 'dev@techpartner.com',
    preview: 'We\'re experiencing issues with the API integration. Getting 404 errors on endpoint...',
    receivedAt: '2026-01-14T14:20:00Z',
    isRead: false,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN009',
    subject: 'Social media mention',
    sender: 'Twitter User',
    senderEmail: 'mention@twitter.com',
    preview: '@YourCompany Your product is amazing! But I have a question about...',
    receivedAt: '2026-01-14T12:10:00Z',
    isRead: true,
    isStarred: false,
    channel: 'SOCIAL',
    hasAttachment: false,
  },
  {
    id: 'IN010',
    subject: 'Phone voicemail transcript',
    sender: 'Phone System',
    senderEmail: 'phone@company.com',
    preview: 'Customer called regarding shipping delay. Callback requested at +1-555-0123...',
    receivedAt: '2026-01-14T11:30:00Z',
    isRead: true,
    isStarred: false,
    channel: 'PHONE',
    hasAttachment: false,
  },
  {
    id: 'IN011',
    subject: 'Partnership opportunity',
    sender: 'Business Development',
    senderEmail: 'bizdev@potential.com',
    preview: 'We\'d like to explore a strategic partnership with your company...',
    receivedAt: '2026-01-14T10:00:00Z',
    isRead: true,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: true,
  },
  {
    id: 'IN012',
    subject: 'Security concern report',
    sender: 'Security Researcher',
    senderEmail: 'security@researcher.com',
    preview: 'I\'ve identified a potential vulnerability in your login system...',
    receivedAt: '2026-01-14T09:15:00Z',
    isRead: false,
    isStarred: true,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN013',
    subject: 'Product feedback',
    sender: 'Loyal Customer',
    senderEmail: 'loyal@customer.com',
    preview: 'Been using your service for 3 years. Here are my thoughts on the latest update...',
    receivedAt: '2026-01-13T20:45:00Z',
    isRead: true,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN014',
    subject: 'Training session inquiry',
    sender: 'HR Manager',
    senderEmail: 'hr@enterprise.com',
    preview: 'We\'d like to schedule a training session for our team of 50...',
    receivedAt: '2026-01-13T16:30:00Z',
    isRead: true,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: false,
  },
  {
    id: 'IN015',
    subject: 'Bug report: Mobile app crash',
    sender: 'Beta Tester',
    senderEmail: 'beta@tester.com',
    preview: 'App crashes when I try to upload photos. Steps to reproduce: 1. Open app...',
    receivedAt: '2026-01-13T14:20:00Z',
    isRead: false,
    isStarred: false,
    channel: 'EMAIL',
    hasAttachment: true,
  },
]

// Mock Cases
export const mockCases: Case[] = [
  {
    id: 'K-2026-0001',
    title: 'Payment processing failure',
    description: 'Customer unable to complete payment transaction. Multiple attempts failed.',
    status: 'IN_PROGRESS',
    priority: 'HIGH',
    customerName: 'John Smith',
    customerEmail: 'john.smith@customer.com',
    assignedTo: 'A002',
    channel: 'EMAIL',
    createdAt: '2026-01-15T09:30:00Z',
    updatedAt: '2026-01-15T10:15:00Z',
    dueDate: '2026-01-16T09:30:00Z',
    tags: ['payment', 'urgent', 'billing'],
  },
  {
    id: 'K-2026-0002',
    title: 'Product warranty inquiry',
    description: 'Customer requesting clarification on warranty terms for laptop purchase.',
    status: 'ASSIGNED',
    priority: 'MEDIUM',
    customerName: 'Maria Garcia',
    customerEmail: 'maria.g@email.com',
    assignedTo: 'A003',
    channel: 'EMAIL',
    createdAt: '2026-01-15T08:45:00Z',
    updatedAt: '2026-01-15T09:00:00Z',
    dueDate: '2026-01-17T08:45:00Z',
    tags: ['warranty', 'product'],
  },
  {
    id: 'K-2026-0003',
    title: 'Account login issues',
    description: 'Customer cannot access account despite correct credentials.',
    status: 'NEW',
    priority: 'HIGH',
    customerName: 'Lisa Anderson',
    customerEmail: 'lisa.a@email.com',
    assignedTo: undefined,
    channel: 'EMAIL',
    createdAt: '2026-01-15T07:20:00Z',
    updatedAt: '2026-01-15T07:20:00Z',
    dueDate: '2026-01-15T19:20:00Z',
    tags: ['account', 'login', 'urgent'],
  },
  {
    id: 'K-2026-0004',
    title: 'Refund request - Damaged item',
    description: 'Customer received damaged product and requests full refund.',
    status: 'PENDING',
    priority: 'MEDIUM',
    customerName: 'Robert Wilson',
    customerEmail: 'rwilson@customer.com',
    assignedTo: 'A002',
    channel: 'EMAIL',
    createdAt: '2026-01-15T07:50:00Z',
    updatedAt: '2026-01-15T11:30:00Z',
    dueDate: '2026-01-18T07:50:00Z',
    tags: ['refund', 'damaged', 'shipping'],
  },
  {
    id: 'K-2026-0005',
    title: 'API integration error',
    description: 'Partner experiencing 404 errors on API endpoints.',
    status: 'IN_PROGRESS',
    priority: 'CRITICAL',
    customerName: 'Tech Partner Inc',
    customerEmail: 'dev@techpartner.com',
    assignedTo: 'A004',
    channel: 'EMAIL',
    createdAt: '2026-01-14T14:20:00Z',
    updatedAt: '2026-01-15T08:00:00Z',
    dueDate: '2026-01-14T20:20:00Z',
    tags: ['api', 'integration', 'critical'],
  },
  {
    id: 'K-2026-0006',
    title: 'Security vulnerability report',
    description: 'Security researcher reported potential login vulnerability.',
    status: 'ASSIGNED',
    priority: 'CRITICAL',
    customerName: 'Security Researcher',
    customerEmail: 'security@researcher.com',
    assignedTo: 'A004',
    channel: 'EMAIL',
    createdAt: '2026-01-14T09:15:00Z',
    updatedAt: '2026-01-14T10:00:00Z',
    dueDate: '2026-01-14T21:15:00Z',
    tags: ['security', 'vulnerability', 'critical'],
  },
  {
    id: 'K-2026-0007',
    title: 'Mobile app crash on photo upload',
    description: 'App crashes consistently when uploading photos in iOS version.',
    status: 'NEW',
    priority: 'HIGH',
    customerName: 'Beta Tester',
    customerEmail: 'beta@tester.com',
    assignedTo: undefined,
    channel: 'EMAIL',
    createdAt: '2026-01-13T14:20:00Z',
    updatedAt: '2026-01-13T14:20:00Z',
    dueDate: '2026-01-16T14:20:00Z',
    tags: ['mobile', 'bug', 'ios'],
  },
  {
    id: 'K-2026-0008',
    title: 'Shipping delay inquiry',
    description: 'Customer concerned about delayed shipment for order #98765.',
    status: 'RESOLVED',
    priority: 'LOW',
    customerName: 'Phone Customer',
    customerEmail: 'callback@requested.com',
    assignedTo: 'A003',
    channel: 'PHONE',
    createdAt: '2026-01-14T11:30:00Z',
    updatedAt: '2026-01-15T09:45:00Z',
    dueDate: '2026-01-15T11:30:00Z',
    tags: ['shipping', 'delay'],
  },
  {
    id: 'K-2026-0009',
    title: 'Feature request: Dark mode',
    description: 'Customer requesting dark mode feature for mobile app.',
    status: 'CLOSED',
    priority: 'LOW',
    customerName: 'Tech Enthusiast',
    customerEmail: 'techie@example.com',
    assignedTo: 'A001',
    channel: 'EMAIL',
    createdAt: '2026-01-14T18:30:00Z',
    updatedAt: '2026-01-15T08:00:00Z',
    tags: ['feature-request', 'mobile'],
  },
  {
    id: 'K-2026-0010',
    title: 'Invoice payment terms clarification',
    description: 'Partner requesting clarification on invoice payment terms.',
    status: 'ASSIGNED',
    priority: 'MEDIUM',
    customerName: 'Finance Dept',
    customerEmail: 'finance@partner.com',
    assignedTo: 'A002',
    channel: 'EMAIL',
    createdAt: '2026-01-14T16:45:00Z',
    updatedAt: '2026-01-14T17:00:00Z',
    dueDate: '2026-01-17T16:45:00Z',
    tags: ['billing', 'invoice'],
  },
  {
    id: 'K-2026-0011',
    title: 'Social media response needed',
    description: 'Customer question on Twitter about product features.',
    status: 'NEW',
    priority: 'LOW',
    customerName: 'Twitter User',
    customerEmail: 'mention@twitter.com',
    assignedTo: undefined,
    channel: 'SOCIAL',
    createdAt: '2026-01-14T12:10:00Z',
    updatedAt: '2026-01-14T12:10:00Z',
    dueDate: '2026-01-15T12:10:00Z',
    tags: ['social', 'inquiry'],
  },
  {
    id: 'K-2026-0012',
    title: 'Partnership proposal review',
    description: 'Strategic partnership opportunity from potential partner.',
    status: 'PENDING',
    priority: 'MEDIUM',
    customerName: 'Business Development',
    customerEmail: 'bizdev@potential.com',
    assignedTo: 'A001',
    channel: 'EMAIL',
    createdAt: '2026-01-14T10:00:00Z',
    updatedAt: '2026-01-14T15:30:00Z',
    dueDate: '2026-01-21T10:00:00Z',
    tags: ['partnership', 'business'],
  },
  {
    id: 'K-2026-0013',
    title: 'Product feedback compilation',
    description: 'Long-term customer providing detailed product feedback.',
    status: 'CLOSED',
    priority: 'LOW',
    customerName: 'Loyal Customer',
    customerEmail: 'loyal@customer.com',
    assignedTo: 'A003',
    channel: 'EMAIL',
    createdAt: '2026-01-13T20:45:00Z',
    updatedAt: '2026-01-14T09:00:00Z',
    tags: ['feedback', 'product'],
  },
  {
    id: 'K-2026-0014',
    title: 'Enterprise training request',
    description: 'Enterprise customer requesting training for 50 team members.',
    status: 'IN_PROGRESS',
    priority: 'HIGH',
    customerName: 'HR Manager',
    customerEmail: 'hr@enterprise.com',
    assignedTo: 'A001',
    channel: 'EMAIL',
    createdAt: '2026-01-13T16:30:00Z',
    updatedAt: '2026-01-14T14:00:00Z',
    dueDate: '2026-01-20T16:30:00Z',
    tags: ['training', 'enterprise'],
  },
  {
    id: 'K-2026-0015',
    title: 'Chat support escalation',
    description: 'Complex issue from chat that requires agent follow-up.',
    status: 'ASSIGNED',
    priority: 'MEDIUM',
    customerName: 'Chat Customer',
    customerEmail: 'chat@customer.com',
    assignedTo: 'A002',
    channel: 'CHAT',
    createdAt: '2026-01-15T08:15:00Z',
    updatedAt: '2026-01-15T08:30:00Z',
    dueDate: '2026-01-16T08:15:00Z',
    tags: ['chat', 'escalation'],
  },
  {
    id: 'K-2026-0016',
    title: 'Database connection timeout',
    description: 'Intermittent database connection timeouts reported by monitoring.',
    status: 'NEW',
    priority: 'CRITICAL',
    customerName: 'System Alert',
    customerEmail: 'alerts@company.com',
    assignedTo: undefined,
    channel: 'EMAIL',
    createdAt: '2026-01-15T06:00:00Z',
    updatedAt: '2026-01-15T06:00:00Z',
    dueDate: '2026-01-15T12:00:00Z',
    tags: ['database', 'infrastructure', 'critical'],
  },
  {
    id: 'K-2026-0017',
    title: 'Customer data export request',
    description: 'GDPR data export request from customer.',
    status: 'PENDING',
    priority: 'HIGH',
    customerName: 'Privacy Request',
    customerEmail: 'privacy@customer.com',
    assignedTo: 'A004',
    channel: 'EMAIL',
    createdAt: '2026-01-14T13:00:00Z',
    updatedAt: '2026-01-14T16:00:00Z',
    dueDate: '2026-01-21T13:00:00Z',
    tags: ['gdpr', 'privacy', 'data-export'],
  },
  {
    id: 'K-2026-0018',
    title: 'Subscription renewal issue',
    description: 'Customer subscription not renewing automatically.',
    status: 'IN_PROGRESS',
    priority: 'MEDIUM',
    customerName: 'Subscriber',
    customerEmail: 'sub@customer.com',
    assignedTo: 'A003',
    channel: 'EMAIL',
    createdAt: '2026-01-14T11:00:00Z',
    updatedAt: '2026-01-15T07:30:00Z',
    dueDate: '2026-01-17T11:00:00Z',
    tags: ['subscription', 'billing'],
  },
  {
    id: 'K-2026-0019',
    title: 'UI bug: Button not clickable',
    description: 'Settings save button not responding on mobile view.',
    status: 'ASSIGNED',
    priority: 'MEDIUM',
    customerName: 'Mobile User',
    customerEmail: 'mobile@customer.com',
    assignedTo: 'A002',
    channel: 'CHAT',
    createdAt: '2026-01-13T15:45:00Z',
    updatedAt: '2026-01-14T09:15:00Z',
    dueDate: '2026-01-16T15:45:00Z',
    tags: ['ui', 'bug', 'mobile'],
  },
  {
    id: 'K-2026-0020',
    title: 'Performance degradation report',
    description: 'Customer reporting slow page load times on dashboard.',
    status: 'RESOLVED',
    priority: 'HIGH',
    customerName: 'Power User',
    customerEmail: 'power@customer.com',
    assignedTo: 'A004',
    channel: 'EMAIL',
    createdAt: '2026-01-12T10:30:00Z',
    updatedAt: '2026-01-14T16:45:00Z',
    dueDate: '2026-01-14T10:30:00Z',
    tags: ['performance', 'dashboard'],
  },
]

// Helper functions
export const getAgentById = (id: string): Agent | undefined => {
  return mockAgents.find(agent => agent.id === id)
}

export const getCaseById = (id: string): Case | undefined => {
  return mockCases.find(c => c.id === id)
}

export const getChannelById = (id: string): Channel | undefined => {
  return mockChannels.find(channel => channel.id === id)
}

export const getInboxItemById = (id: string): InboxItem | undefined => {
  return mockInboxItems.find(item => item.id === id)
}
