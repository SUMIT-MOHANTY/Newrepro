import React, { createContext, useContext, useState, useCallback, useEffect } from 'react'

interface User {
  id: string
  email: string
  name: string
  role: 'admin' | 'agent' | 'supervisor'
  avatar?: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  refreshToken: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

const MOCK_USER: User = {
  id: '1',
  email: 'agent@example.com',
  name: 'Sarah Johnson',
  role: 'agent',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=Sarah',
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  // Check for existing token on mount
  useEffect(() => {
    const token = localStorage.getItem('auth_token')
    if (token) {
      // In a real app, validate the token with the backend
      setUser(MOCK_USER)
    }
    setIsLoading(false)
  }, [])

  const login = useCallback(async (email: string, password: string) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500))
    
    // For demo purposes, accept any credentials
    const token = 'mock_jwt_token_' + Date.now()
    localStorage.setItem('auth_token', token)
    setUser(MOCK_USER)
  }, [])

  const logout = useCallback(() => {
    localStorage.removeItem('auth_token')
    setUser(null)
  }, [])

  const refreshToken = useCallback(async () => {
    // Simulate token refresh
    await new Promise(resolve => setTimeout(resolve, 300))
    const newToken = 'mock_jwt_token_' + Date.now()
    localStorage.setItem('auth_token', newToken)
  }, [])

  const value: AuthContextType = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
    refreshToken,
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}
