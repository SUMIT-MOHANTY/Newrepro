import { useState } from 'react'
import {
  ChatBubbleLeftRightIcon,
  PlusIcon,
  CheckCircleIcon,
  XCircleIcon,
  ExclamationCircleIcon,
  EnvelopeIcon,
  DevicePhoneMobileIcon,
  PaperAirplaneIcon,
} from '@heroicons/react/24/outline'

interface Channel {
  id: string
  name: string
  type: 'email' | 'whatsapp' | 'telegram' | 'sms'
  status: 'connected' | 'disconnected' | 'error'
  identifier: string
  messagesReceived: number
  messagesSent: number
  lastActivity: string
}

export function ChannelsPage() {
  const [channels] = useState<Channel[]>([
    {
      id: '1',
      name: 'Support Email',
      type: 'email',
      status: 'connected',
      identifier: 'support@example.com',
      messagesReceived: 1234,
      messagesSent: 987,
      lastActivity: '2 minutes ago',
    },
    {
      id: '2',
      name: 'WhatsApp Business',
      type: 'whatsapp',
      status: 'connected',
      identifier: '+1234567890',
      messagesReceived: 567,
      messagesSent: 432,
      lastActivity: '5 minutes ago',
    },
    {
      id: '3',
      name: 'Telegram Bot',
      type: 'telegram',
      status: 'error',
      identifier: '@support_bot',
      messagesReceived: 234,
      messagesSent: 198,
      lastActivity: '1 hour ago',
    },
    {
      id: '4',
      name: 'SMS Gateway',
      type: 'sms',
      status: 'disconnected',
      identifier: '+1987654321',
      messagesReceived: 0,
      messagesSent: 0,
      lastActivity: '3 days ago',
    },
  ])

  const getChannelIcon = (type: string) => {
    switch (type) {
      case 'email':
        return <EnvelopeIcon className="w-5 h-5" />
      case 'whatsapp':
        return <DevicePhoneMobileIcon className="w-5 h-5" />
      case 'telegram':
        return <PaperAirplaneIcon className="w-5 h-5" />
      case 'sms':
        return <ChatBubbleLeftRightIcon className="w-5 h-5" />
      default:
        return <ChatBubbleLeftRightIcon className="w-5 h-5" />
    }
  }

  const getChannelColor = (type: string) => {
    switch (type) {
      case 'email':
        return 'bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'
      case 'whatsapp':
        return 'bg-green-100 text-green-600 dark:bg-green-900/30 dark:text-green-400'
      case 'telegram':
        return 'bg-sky-100 text-sky-600 dark:bg-sky-900/30 dark:text-sky-400'
      case 'sms':
        return 'bg-purple-100 text-purple-600 dark:bg-purple-900/30 dark:text-purple-400'
      default:
        return 'bg-gray-100 text-gray-600'
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected':
        return <CheckCircleIcon className="w-5 h-5 text-green-500" />
      case 'disconnected':
        return <XCircleIcon className="w-5 h-5 text-gray-400" />
      case 'error':
        return <ExclamationCircleIcon className="w-5 h-5 text-red-500" />
      default:
        return null
    }
  }

  const connectedCount = channels.filter((c) => c.status === 'connected').length
  const totalMessages = channels.reduce(
    (sum, c) => sum + c.messagesReceived + c.messagesSent,
    0
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Channels
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-400">
            Manage communication channels and integrations
          </p>
        </div>
        <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
          <PlusIcon className="w-5 h-5 mr-2" />
          Add Channel
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
              <ChatBubbleLeftRightIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Channels</p>
              <p className="text-lg font-semibold text-gray-900 dark:text-white">
                {channels.length}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
              <CheckCircleIcon className="w-5 h-5 text-green-600 dark:text-green-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-600 dark:text-gray-400">Connected</p>
              <p className="text-lg font-semibold text-gray-900 dark:text-white">
                {connectedCount}
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
          <div className="flex items-center">
            <div className="p-2 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
              <EnvelopeIcon className="w-5 h-5 text-purple-600 dark:text-purple-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-gray-600 dark:text-gray-400">Total Messages</p>
              <p className="text-lg font-semibold text-gray-900 dark:text-white">
                {totalMessages.toLocaleString()}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Channels Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {channels.map((channel) => (
          <div
            key={channel.id}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center ${getChannelColor(
                    channel.type
                  )}`}
                >
                  {getChannelIcon(channel.type)}
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-900 dark:text-white">
                    {channel.name}
                  </h3>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {channel.identifier}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                {getStatusIcon(channel.status)}
                <span
                  className={`text-xs font-medium ${
                    channel.status === 'connected'
                      ? 'text-green-600 dark:text-green-400'
                      : channel.status === 'error'
                      ? 'text-red-600 dark:text-red-400'
                      : 'text-gray-500 dark:text-gray-400'
                  }`}
                >
                  {channel.status.charAt(0).toUpperCase() + channel.status.slice(1)}
                </span>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Received</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {channel.messagesReceived.toLocaleString()}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Sent</p>
                  <p className="text-sm font-semibold text-gray-900 dark:text-white">
                    {channel.messagesSent.toLocaleString()}
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700 flex items-center justify-between">
              <span className="text-xs text-gray-500 dark:text-gray-400">
                Last activity: {channel.lastActivity}
              </span>
              <button className="text-sm text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                Configure
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Empty State */}
      {channels.length === 0 && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
          <ChatBubbleLeftRightIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No channels configured
          </h3>
          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
            Add your first communication channel to start receiving messages
          </p>
          <button className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
            <PlusIcon className="w-5 h-5 mr-2" />
            Add Channel
          </button>
        </div>
      )}
    </div>
  )
}
