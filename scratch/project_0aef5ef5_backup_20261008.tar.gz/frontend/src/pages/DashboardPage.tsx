import { useEffect, useState } from 'react'
import {
  InboxIcon,
  FolderIcon,
  UsersIcon,
  ChatBubbleLeftRightIcon,
} from '@heroicons/react/24/outline'

interface DashboardStats {
  activeCases: number
  unreadMessages: number
  activeAgents: number
  connectedChannels: number
}

export function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats>({
    activeCases: 0,
    unreadMessages: 0,
    activeAgents: 0,
    connectedChannels: 0,
  })
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching dashboard stats
    const fetchStats = async () => {
      setIsLoading(true)
      // In a real app, this would be an API call
      await new Promise((resolve) => setTimeout(resolve, 500))
      setStats({
        activeCases: 12,
        unreadMessages: 5,
        activeAgents: 3,
        connectedChannels: 4,
      })
      setIsLoading(false)
    }

    fetchStats()
  }, [])

  const statCards = [
    {
      name: 'Active Cases',
      value: stats.activeCases,
      icon: FolderIcon,
      color: 'bg-blue-500',
      href: '/cases',
    },
    {
      name: 'Unread Messages',
      value: stats.unreadMessages,
      icon: InboxIcon,
      color: 'bg-green-500',
      href: '/inbox',
    },
    {
      name: 'Active Agents',
      value: stats.activeAgents,
      icon: UsersIcon,
      color: 'bg-purple-500',
      href: '/agents',
    },
    {
      name: 'Connected Channels',
      value: stats.connectedChannels,
      icon: ChatBubbleLeftRightIcon,
      color: 'bg-orange-500',
      href: '/channels',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          Dashboard
        </h1>
        <p className="mt-1 text-gray-600 dark:text-gray-400">
          Overview of your support operations
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <div
            key={stat.name}
            className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6 hover:shadow-md transition-shadow cursor-pointer"
          >
            <div className="flex items-center">
              <div className={`${stat.color} rounded-lg p-3`}>
                <stat.icon className="w-6 h-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">
                  {stat.name}
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">
                  {isLoading ? '-' : stat.value}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Recent Activity Section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            Recent Activity
          </h2>
        </div>
        <div className="p-6">
          {isLoading ? (
            <div className="animate-pulse space-y-4">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-12 bg-gray-200 dark:bg-gray-700 rounded" />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                    <span className="text-sm font-medium text-blue-600 dark:text-blue-400">
                      JD
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      New case created
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Case #1234 - Technical Support
                    </p>
                  </div>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  2 min ago
                </span>
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <span className="text-sm font-medium text-green-600 dark:text-green-400">
                      AS
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Message received
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      From customer via WhatsApp
                    </p>
                  </div>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  5 min ago
                </span>
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 dark:bg-purple-900/30 flex items-center justify-center">
                    <span className="text-sm font-medium text-purple-600 dark:text-purple-400">
                      MK
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      Case resolved
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Case #1230 - Closed by Agent
                    </p>
                  </div>
                </div>
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  15 min ago
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
