import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { FolderIcon, PlusIcon, FunnelIcon } from '@heroicons/react/24/outline'
import { Table } from '../components/common/Table'
import type { Column } from '../components/common/Table'
import { SearchInput } from '../components/common/SearchInput'
import { Pagination } from '../components/common/Pagination'
import { StatusBadge } from '../components/common/StatusBadge'
import { Button } from '../components/common/Button'
import { mockCases } from '../mocks/mockData'
import type { Case } from '../mocks/mockData'
import type { CaseStatus, Priority } from '../mocks/mockData'

export function CasesPage() {
  const navigate = useNavigate()
  const [cases, setCases] = useState<Case[]>([])
  const [filteredCases, setFilteredCases] = useState<Case[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<CaseStatus | 'ALL'>('ALL')
  const [priorityFilter, setPriorityFilter] = useState<Priority | 'ALL'>('ALL')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  useEffect(() => {
    const fetchCases = async () => {
      setIsLoading(true)
      await new Promise(resolve => setTimeout(resolve, 500))
      setCases(mockCases)
      setFilteredCases(mockCases)
      setIsLoading(false)
    }
    fetchCases()
  }, [])

  useEffect(() => {
    let filtered = cases

    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        c =>
          c.id.toLowerCase().includes(query) ||
          c.title.toLowerCase().includes(query) ||
          c.customerName.toLowerCase().includes(query) ||
          c.customerEmail.toLowerCase().includes(query)
      )
    }

    if (statusFilter !== 'ALL') {
      filtered = filtered.filter(c => c.status === statusFilter)
    }

    if (priorityFilter !== 'ALL') {
      filtered = filtered.filter(c => c.priority === priorityFilter)
    }

    setFilteredCases(filtered)
    setCurrentPage(1)
  }, [searchQuery, statusFilter, priorityFilter, cases])

  const totalPages = Math.ceil(filteredCases.length / itemsPerPage)
  const paginatedCases = filteredCases.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  const columns: Column<Case>[] = [
    {
      key: 'id',
      header: 'Case ID',
      width: 'w-32',
      render: (row) => (
        <span className="font-mono text-sm text-gray-900 dark:text-white">
          {row.id}
        </span>
      ),
    },
    {
      key: 'title',
      header: 'Title',
      render: (row) => (
        <div>
          <p className="text-gray-900 dark:text-white font-medium">{row.title}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-xs">
            {row.customerName}
          </p>
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      width: 'w-32',
      render: (row) => <StatusBadge status={row.status} size="sm" />,
    },
    {
      key: 'priority',
      header: 'Priority',
      width: 'w-28',
      render: (row) => <StatusBadge status={row.priority} size="sm" />,
    },
    {
      key: 'assignedTo',
      header: 'Assigned To',
      width: 'w-40',
      render: (row) => (
        <span className="text-gray-700 dark:text-gray-300">
          {row.assignedTo || 'Unassigned'}
        </span>
      ),
    },
    {
      key: 'createdAt',
      header: 'Created',
      width: 'w-32',
      render: (row) => (
        <span className="text-gray-500 dark:text-gray-400">
          {formatDate(row.createdAt)}
        </span>
      ),
    },
  ]

  const statusOptions: { value: CaseStatus | 'ALL'; label: string }[] = [
    { value: 'ALL', label: 'All Statuses' },
    { value: 'NEW', label: 'New' },
    { value: 'ASSIGNED', label: 'Assigned' },
    { value: 'IN_PROGRESS', label: 'In Progress' },
    { value: 'PENDING', label: 'Pending' },
    { value: 'RESOLVED', label: 'Resolved' },
    { value: 'CLOSED', label: 'Closed' },
  ]

  const priorityOptions: { value: Priority | 'ALL'; label: string }[] = [
    { value: 'ALL', label: 'All Priorities' },
    { value: 'LOW', label: 'Low' },
    { value: 'MEDIUM', label: 'Medium' },
    { value: 'HIGH', label: 'High' },
    { value: 'CRITICAL', label: 'Critical' },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Cases
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-400">
            Manage and track customer cases
          </p>
        </div>
        <Button leftIcon={<PlusIcon className="w-5 h-5" />}>
          New Case
        </Button>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1 max-w-md">
          <SearchInput
            placeholder="Search cases..."
            value={searchQuery}
            onChange={setSearchQuery}
          />
        </div>
        <div className="flex items-center gap-2">
          <FunnelIcon className="w-5 h-5 text-gray-400" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as CaseStatus | 'ALL')}
            className="px-3 py-2 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-brand-500"
          >
            {statusOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as Priority | 'ALL')}
            className="px-3 py-2 text-sm bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:ring-2 focus:ring-brand-500"
          >
            {priorityOptions.map(option => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Cases Table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <Table
          columns={columns}
          data={paginatedCases}
          keyExtractor={(row) => row.id}
          loading={isLoading}
          onRowClick={(row) => navigate(`/cases/${row.id}`)}
          emptyState={
            <div className="flex flex-col items-center justify-center py-12">
              <FolderIcon className="w-12 h-12 text-gray-400 mb-4" />
              <p className="text-gray-900 dark:text-white font-medium">No cases found</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">No cases match your search criteria.</p>
            </div>
          }
        />
        {!isLoading && filteredCases.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={filteredCases.length}
            itemsPerPage={itemsPerPage}
          />
        )}
      </div>
    </div>
  )
}
