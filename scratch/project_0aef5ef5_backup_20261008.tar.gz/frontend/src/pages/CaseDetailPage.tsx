import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import {
  ArrowLeftIcon,
  ChatBubbleLeftRightIcon,
  PaperClipIcon,
  ClockIcon,
  UserIcon,
} from '@heroicons/react/24/outline'
import { mockCases } from '../mocks/mockData'
import type { Case, CaseStatus, Priority } from '../mocks/mockData'

// Local interface extending the mockData type with additional UI-specific fields
interface CaseDetail extends Case {
  id: string
  title: string
  description: string
  status: CaseStatus
  priority: Priority
  customerName: string
  customerEmail: string
  assignedTo?: string
  channel: string
  createdAt: string
  updatedAt: string
  dueDate?: string
  tags: string[]
}

interface Comment {
  id: string
  author: string
  content: string
  timestamp: string
}

export function CaseDetailPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const [caseDetail, setCaseDetail] = useState<CaseDetail | null>(null)
  const [comments, setComments] = useState<Comment[]>([])
  const [newComment, setNewComment] = useState('')
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching case details
    const fetchCaseDetail = async () => {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 500))
      
      // Mock data for demo - in real app, fetch from API
      const baseCase: Case = {
        id: id || 'K-2026-0001',
        title: 'Payment processing failure',
        description: 'Customer unable to complete payment transaction. Multiple attempts failed.',
        status: 'IN_PROGRESS',
        priority: 'HIGH',
        customerName: 'John Smith',
        customerEmail: 'john.smith@customer.com',
        assignedTo: 'A002',
        channel: 'EMAIL',
        createdAt: '2026-01-15T09:30:00Z',
        updatedAt: '2026-01-15T10:15:00Z',
        dueDate: '2026-01-16T09:30:00Z',
        tags: ['payment', 'urgent', 'billing'],
      }
      setCaseDetail(baseCase)

      setComments([
        {
          id: '1',
          author: 'john.doe@example.com',
          content: 'I have tried resetting my password multiple times but still cannot log in.',
          timestamp: '2024-01-15T10:35:00Z',
        },
        {
          id: '2',
          author: 'Agent Smith',
          content: 'Thank you for reporting this. Can you please confirm if you are receiving the password reset email?',
          timestamp: '2024-01-15T11:00:00Z',
        },
      ])
      
      setIsLoading(false)
    }

    fetchCaseDetail()
  }, [id])

  const handleAddComment = () => {
    if (!newComment.trim()) return
    
    const comment: Comment = {
      id: String(Date.now()),
      author: 'Current User',
      content: newComment,
      timestamp: new Date().toISOString(),
    }
    
    setComments([...comments, comment])
    setNewComment('')
  }

  const getStatusColor = (status: CaseStatus) => {
    switch (status) {
      case 'NEW':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
      case 'ASSIGNED':
        return 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-400'
      case 'IN_PROGRESS':
        return 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400'
      case 'PENDING':
        return 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400'
      case 'RESOLVED':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
      case 'CLOSED':
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  const getPriorityColor = (priority: Priority) => {
    switch (priority) {
      case 'CRITICAL':
        return 'text-red-600 dark:text-red-400'
      case 'HIGH':
        return 'text-orange-600 dark:text-orange-400'
      case 'MEDIUM':
        return 'text-yellow-600 dark:text-yellow-400'
      case 'LOW':
        return 'text-green-600 dark:text-green-400'
      default:
        return 'text-gray-600'
    }
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!caseDetail) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-600 dark:text-gray-400">Case not found</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <button
          onClick={() => navigate('/cases')}
          className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
        >
          <ArrowLeftIcon className="w-5 h-5 text-gray-600 dark:text-gray-400" />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            {caseDetail.title}
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Case #{caseDetail.id}
          </p>
        </div>
      </div>

      {/* Case Info */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div>
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Status
            </label>
            <span
              className={`mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(
                caseDetail.status
              )}`}
            >
              {caseDetail.status.replace(/_/g, ' ')}
            </span>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Priority
            </label>
            <p className={`mt-1 text-sm font-medium ${getPriorityColor(caseDetail.priority)}`}>
              {caseDetail.priority.charAt(0) + caseDetail.priority.slice(1).toLowerCase()}
            </p>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Customer
            </label>
            <p className="mt-1 text-sm text-gray-900 dark:text-white">
              {caseDetail.customerName}
            </p>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              {caseDetail.customerEmail}
            </p>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Assigned To
            </label>
            <p className="mt-1 text-sm text-gray-900 dark:text-white">
              {caseDetail.assignedTo || 'Unassigned'}
            </p>
          </div>
          <div>
            <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Channel
            </label>
            <p className="mt-1 text-sm text-gray-900 dark:text-white">
              {caseDetail.channel}
            </p>
          </div>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
          <label className="text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
            Description
          </label>
          <p className="mt-2 text-sm text-gray-700 dark:text-gray-300">
            {caseDetail.description}
          </p>
        </div>

        <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700 flex items-center gap-6 text-sm text-gray-500 dark:text-gray-400">
          <div className="flex items-center gap-2">
            <ClockIcon className="w-4 h-4" />
            <span>Created: {new Date(caseDetail.createdAt).toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-2">
            <ClockIcon className="w-4 h-4" />
            <span>Updated: {new Date(caseDetail.updatedAt).toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Comments Section */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="px-6 py-4 border-b border-gray-200 dark:border-gray-700">
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center gap-2">
            <ChatBubbleLeftRightIcon className="w-5 h-5" />
            Comments
          </h2>
        </div>

        <div className="p-6 space-y-4">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className="flex gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg"
            >
              <div className="flex-shrink-0">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                  <UserIcon className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {comment.author}
                  </p>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {new Date(comment.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="mt-1 text-sm text-gray-700 dark:text-gray-300">
                  {comment.content}
                </p>
              </div>
            </div>
          ))}

          {/* Add Comment */}
          <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
            <textarea
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              placeholder="Add a comment..."
              rows={3}
              className="w-full px-4 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            />
            <div className="mt-3 flex justify-end">
              <button
                onClick={handleAddComment}
                disabled={!newComment.trim()}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                Add Comment
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
