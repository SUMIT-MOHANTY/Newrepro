import { useState, useEffect } from 'react'
import { EnvelopeIcon, EnvelopeOpenIcon, StarIcon } from '@heroicons/react/24/outline'
import { StarIcon as StarIconSolid } from '@heroicons/react/24/solid'
import { Table } from '../components/common/Table'
import type { Column } from '../components/common/Table'
import { SearchInput } from '../components/common/SearchInput'
import { Pagination } from '../components/common/Pagination'
import { mockInboxItems } from '../mocks/mockData'
import type { InboxItem } from '../mocks/mockData'
import type { ChannelType } from '../mocks/mockData'

const channelColors: Record<ChannelType, string> = {
  EMAIL: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200',
  CHAT: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200',
  PHONE: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-200',
  SOCIAL: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-200',
}

export function InboxPage() {
  const [items, setItems] = useState<InboxItem[]>([])
  const [filteredItems, setFilteredItems] = useState<InboxItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState('')
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 10

  useEffect(() => {
    // Simulate API call
    const fetchItems = async () => {
      setIsLoading(true)
      await new Promise(resolve => setTimeout(resolve, 500))
      setItems(mockInboxItems)
      setFilteredItems(mockInboxItems)
      setIsLoading(false)
    }
    fetchItems()
  }, [])

  useEffect(() => {
    let filtered = items
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = items.filter(
        item =>
          item.subject.toLowerCase().includes(query) ||
          item.sender.toLowerCase().includes(query) ||
          item.preview.toLowerCase().includes(query)
      )
    }
    setFilteredItems(filtered)
    setCurrentPage(1)
  }, [searchQuery, items])

  const toggleStar = (id: string) => {
    setItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, isStarred: !item.isStarred } : item
      )
    )
  }

  const markAsRead = (id: string) => {
    setItems(prev =>
      prev.map(item =>
        item.id === id ? { ...item, isRead: true } : item
      )
    )
  }

  const totalPages = Math.ceil(filteredItems.length / itemsPerPage)
  const paginatedItems = filteredItems.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  const columns: Column<InboxItem>[] = [
    {
      key: 'starred',
      header: '',
      width: 'w-12',
      render: (row) => (
        <button
          onClick={() => toggleStar(row.id)}
          className="p-1 rounded hover:bg-gray-100 dark:hover:bg-gray-700"
        >
          {row.isStarred ? (
            <StarIconSolid className="w-5 h-5 text-amber-400" />
          ) : (
            <StarIcon className="w-5 h-5 text-gray-400" />
          )}
        </button>
      ),
    },
    {
      key: 'read',
      header: '',
      width: 'w-12',
      render: (row) => (
        <button onClick={() => markAsRead(row.id)}>
          {row.isRead ? (
            <EnvelopeOpenIcon className="w-5 h-5 text-gray-400" />
          ) : (
            <EnvelopeIcon className="w-5 h-5 text-blue-500" />
          )}
        </button>
      ),
    },
    {
      key: 'subject',
      header: 'Subject',
      render: (row) => (
        <div className={`${!row.isRead ? 'font-semibold' : ''}`}>
          <p className="text-gray-900 dark:text-white">{row.subject}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400 truncate max-w-md">
            {row.preview}
          </p>
        </div>
      ),
    },
    {
      key: 'sender',
      header: 'From',
      render: (row) => (
        <div>
          <p className="text-gray-900 dark:text-white">{row.sender}</p>
          <p className="text-sm text-gray-500 dark:text-gray-400">{row.senderEmail}</p>
        </div>
      ),
    },
    {
      key: 'channel',
      header: 'Channel',
      render: (row) => (
        <span
          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${channelColors[row.channel]}`}
        >
          {row.channel}
        </span>
      ),
    },
    {
      key: 'receivedAt',
      header: 'Received',
      render: (row) => (
        <span className="text-gray-500 dark:text-gray-400">
          {formatDate(row.receivedAt)}
        </span>
      ),
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Inbox
          </h1>
          <p className="mt-1 text-gray-600 dark:text-gray-400">
            Manage incoming messages and communications
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {items.filter(i => !i.isRead).length} unread
          </span>
        </div>
      </div>

      {/* Search */}
      <div className="max-w-md">
        <SearchInput
          placeholder="Search messages..."
          value={searchQuery}
          onChange={setSearchQuery}
        />
      </div>

      {/* Messages Table */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
        <Table
          columns={columns}
          data={paginatedItems}
          keyExtractor={(row) => row.id}
          loading={isLoading}
          emptyState={
            <div className="flex flex-col items-center justify-center py-12">
              <EnvelopeIcon className="w-12 h-12 text-gray-400 mb-4" />
              <p className="text-gray-900 dark:text-white font-medium">No messages found</p>
              <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">Your inbox is empty or no messages match your search.</p>
            </div>
          }
        />
        {!isLoading && filteredItems.length > 0 && (
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            totalItems={filteredItems.length}
            itemsPerPage={itemsPerPage}
          />
        )}
      </div>
    </div>
  )
}
