import { useState, useCallback } from 'react'
import { clsx } from 'clsx'
import {
  ChevronUpIcon,
  ChevronDownIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
} from '@heroicons/react/24/outline'

// Re-export Column interface for external use
export type { Column }

// Export Column interface
interface Column<T> {
  key: string
  header: string
  width?: string
  sortable?: boolean
  render?: (row: T) => React.ReactNode
}

// TableEmptyState component - also exported at module level
export interface TableEmptyStateProps {
  title: string
  description: string
  icon?: React.ComponentType<{ className?: string }>
}

export function TableEmptyState({ title, description, icon: Icon }: TableEmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      {Icon && <Icon className="w-12 h-12 text-gray-400 mb-4" />}
      <p className="text-gray-900 dark:text-white font-medium">{title}</p>
      <p className="text-gray-500 dark:text-gray-400 text-sm mt-1">{description}</p>
    </div>
  )
}

interface TableProps<T> {
  columns: Column<T>[]
  data: T[]
  keyExtractor: (row: T) => string
  selectable?: boolean
  selectedKeys?: Set<string>
  onSelectionChange?: (selectedKeys: Set<string>) => void
  emptyState?: React.ReactNode
  loading?: boolean
  sortColumn?: string
  sortDirection?: 'asc' | 'desc'
  onSort?: (column: string, direction: 'asc' | 'desc') => void
  onRowClick?: (row: T) => void
  pagination?: {
    page: number
    pageSize: number
    total: number
    onPageChange: (page: number) => void
  }
}

export function Table<T>({
  columns,
  data,
  keyExtractor,
  selectable = false,
  selectedKeys = new Set(),
  onSelectionChange,
  emptyState,
  loading = false,
  sortColumn,
  sortDirection,
  onSort,
  onRowClick,
  pagination,
}: TableProps<T>) {
  const [internalSortColumn, setInternalSortColumn] = useState<string | undefined>(sortColumn)
  const [internalSortDirection, setInternalSortDirection] = useState<'asc' | 'desc'>(sortDirection || 'asc')

  const currentSortColumn = sortColumn ?? internalSortColumn
  const currentSortDirection = sortDirection ?? internalSortDirection

  const handleSort = useCallback((columnKey: string) => {
    const column = columns.find(c => c.key === columnKey)
    if (!column?.sortable) return

    let newDirection: 'asc' | 'desc'
    if (currentSortColumn === columnKey) {
      newDirection = currentSortDirection === 'asc' ? 'desc' : 'asc'
    } else {
      newDirection = 'asc'
    }

    setInternalSortColumn(columnKey)
    setInternalSortDirection(newDirection)
    onSort?.(columnKey, newDirection)
  }, [columns, currentSortColumn, currentSortDirection, onSort])

  const handleSelectAll = useCallback(() => {
    if (!onSelectionChange) return
    
    if (selectedKeys.size === data.length) {
      onSelectionChange(new Set())
    } else {
      onSelectionChange(new Set(data.map(keyExtractor)))
    }
  }, [data, keyExtractor, onSelectionChange, selectedKeys.size])

  const handleSelectRow = useCallback((key: string) => {
    if (!onSelectionChange) return
    
    const newSelected = new Set(selectedKeys)
    if (newSelected.has(key)) {
      newSelected.delete(key)
    } else {
      newSelected.add(key)
    }
    onSelectionChange(newSelected)
  }, [onSelectionChange, selectedKeys])

  const totalPages = pagination ? Math.ceil(pagination.total / pagination.pageSize) : 1

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200 dark:border-gray-700">
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead className="bg-gray-50 dark:bg-gray-800">
            <tr>
              {selectable && (
                <th className="px-4 py-3 w-12">
                  <input
                    type="checkbox"
                    checked={data.length > 0 && selectedKeys.size === data.length}
                    onChange={handleSelectAll}
                    className="h-4 w-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700"
                  />
                </th>
              )}
              {columns.map((column) => (
                <th
                  key={column.key}
                  className={clsx(
                    'px-4 py-3 text-left text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider',
                    column.sortable && 'cursor-pointer hover:text-gray-700 dark:hover:text-gray-300',
                    column.width
                  )}
                  style={{ width: column.width }}
                  onClick={() => handleSort(column.key)}
                >
                  <div className="flex items-center gap-1">
                    {column.header}
                    {column.sortable && (
                      <span className="inline-flex flex-col">
                        <ChevronUpIcon
                          className={clsx(
                            'w-3 h-3 -mb-0.5',
                            currentSortColumn === column.key && currentSortDirection === 'asc'
                              ? 'text-brand-600 dark:text-brand-400'
                              : 'text-gray-300 dark:text-gray-600'
                          )}
                        />
                        <ChevronDownIcon
                          className={clsx(
                            'w-3 h-3 -mt-0.5',
                            currentSortColumn === column.key && currentSortDirection === 'desc'
                              ? 'text-brand-600 dark:text-brand-400'
                              : 'text-gray-300 dark:text-gray-600'
                          )}
                        />
                      </span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            {loading ? (
              <tr>
                <td
                  colSpan={columns.length + (selectable ? 1 : 0)}
                  className="px-4 py-12 text-center"
                >
                  <div className="flex items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-600" />
                  </div>
                </td>
              </tr>
            ) : data.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + (selectable ? 1 : 0)}
                  className="px-4 py-12 text-center"
                >
                  {emptyState || (
                    <div className="text-gray-500 dark:text-gray-400">
                      <p className="text-sm">No data available</p>
                    </div>
                  )}
                </td>
              </tr>
            ) : (
              data.map((row) => {
                const key = keyExtractor(row)
                const isSelected = selectedKeys.has(key)
                
                return (
                  <tr
                    key={key}
                    onClick={() => onRowClick?.(row)}
                    className={clsx(
                      'hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors',
                      isSelected && 'bg-brand-50 dark:bg-brand-900/10',
                      onRowClick && 'cursor-pointer'
                    )}
                  >
                    {selectable && (
                      <td className="px-4 py-4" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleSelectRow(key)}
                          className="h-4 w-4 rounded border-gray-300 text-brand-600 focus:ring-brand-500 dark:border-gray-600 dark:bg-gray-700"
                        />
                      </td>
                    )}
                    {columns.map((column) => (
                      <td
                        key={`${key}-${column.key}`}
                        className="px-4 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-gray-100"
                      >
                        {column.render
                          ? column.render(row)
                          : (row as Record<string, unknown>)[column.key] as React.ReactNode}
                      </td>
                    ))}
                  </tr>
                )
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pagination && totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 bg-gray-50 dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            Showing{' '}
            <span className="font-medium">{(pagination.page - 1) * pagination.pageSize + 1}</span>{' '}
            to{' '}
            <span className="font-medium">
              {Math.min(pagination.page * pagination.pageSize, pagination.total)}
            </span>{' '}
            of <span className="font-medium">{pagination.total}</span> results
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => pagination.onPageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Previous page"
            >
              <ChevronLeftIcon className="w-5 h-5" />
            </button>
            <span className="text-sm text-gray-600 dark:text-gray-300">
              Page {pagination.page} of {totalPages}
            </span>
            <button
              onClick={() => pagination.onPageChange(pagination.page + 1)}
              disabled={pagination.page === totalPages}
              className="p-2 rounded-lg text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              aria-label="Next page"
            >
              <ChevronRightIcon className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
