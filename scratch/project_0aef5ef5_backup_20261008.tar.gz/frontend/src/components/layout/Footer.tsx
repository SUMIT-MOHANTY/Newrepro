import { useState, useEffect } from 'react'
import { CheckCircleIcon, ExclamationCircleIcon } from '@heroicons/react/24/solid'

export function Footer() {
  const [apiStatus, setApiStatus] = useState<'online' | 'offline'>('online')
  const [version] = useState('v1.0.0')

  // Simulate API status check
  useEffect(() => {
    const checkStatus = () => {
      // In a real app, this would ping the backend
      setApiStatus('online')
    }
    checkStatus()
    const interval = setInterval(checkStatus, 30000)
    return () => clearInterval(interval)
  }, [])

  return (
    <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 px-4 sm:px-6 py-3">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-4">
          <span className="text-gray-500 dark:text-gray-400">
            Kuoni CMS <span className="text-gray-400 dark:text-gray-500">{version}</span>
          </span>
          <span className="hidden sm:inline text-gray-300 dark:text-gray-600">|</span>
          <span className="hidden sm:inline text-gray-500 dark:text-gray-400">
            © 2026 Kuoni Travel. All rights reserved.
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-gray-500 dark:text-gray-400 hidden sm:inline">API Status:</span>
          <div className="flex items-center gap-1.5">
            {apiStatus === 'online' ? (
              <>
                <CheckCircleIcon className="w-4 h-4 text-green-500" />
                <span className="text-green-600 dark:text-green-400 font-medium">Online</span>
              </>
            ) : (
              <>
                <ExclamationCircleIcon className="w-4 h-4 text-red-500" />
                <span className="text-red-600 dark:text-red-400 font-medium">Offline</span>
              </>
            )}
          </div>
        </div>
      </div>
    </footer>
  )
}
