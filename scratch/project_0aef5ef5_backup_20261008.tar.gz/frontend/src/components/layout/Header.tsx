import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  MagnifyingGlassIcon,
  BellIcon,
  SunIcon,
  MoonIcon,
  ChevronDownIcon,
  ArrowRightOnRectangleIcon,
  UserCircleIcon,
  Cog6ToothIcon,
} from '@heroicons/react/24/outline'
import { useAuth } from '../../contexts/AuthContext'
import { useTheme } from '../../contexts/ThemeContext'
import { SearchInput } from '../common/SearchInput'
import { Dropdown } from '../common/Dropdown'

export function Header() {
  const { user, logout } = useAuth()
  const { theme, toggleTheme } = useTheme()
  const navigate = useNavigate()
  const [showSearch, setShowSearch] = useState(false)

  const handleSearch = (query: string) => {
    if (query.trim()) {
      navigate(`/cases?search=${encodeURIComponent(query)}`)
    }
  }

  const userMenuItems = [
    {
      label: 'Profile',
      icon: UserCircleIcon,
      onClick: () => navigate('/profile'),
    },
    {
      label: 'Settings',
      icon: Cog6ToothIcon,
      onClick: () => navigate('/settings'),
    },
    { divider: true },
    {
      label: 'Sign out',
      icon: ArrowRightOnRectangleIcon,
      onClick: logout,
      danger: true,
    },
  ]

  return (
    <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 sm:px-6 py-4">
      <div className="flex items-center justify-between gap-4">
        {/* Search */}
        <div className="flex-1 max-w-xl">
          <div className="hidden sm:block">
            <SearchInput
              placeholder="Search cases, agents, or messages..."
              onSearch={handleSearch}
              debounceMs={500}
            />
          </div>
          <button
            onClick={() => setShowSearch(!showSearch)}
            className="sm:hidden p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200"
          >
            <MagnifyingGlassIcon className="w-5 h-5" />
          </button>
        </div>

        {/* Mobile search expand */}
        {showSearch && (
          <div className="fixed inset-x-0 top-16 z-50 p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sm:hidden">
            <SearchInput
              placeholder="Search..."
              onSearch={handleSearch}
              autoFocus
            />
          </div>
        )}

        {/* Right side actions */}
        <div className="flex items-center gap-2 sm:gap-4">
          {/* Theme toggle */}
          <button
            onClick={toggleTheme}
            className="p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {theme === 'dark' ? (
              <SunIcon className="w-5 h-5" />
            ) : (
              <MoonIcon className="w-5 h-5" />
            )}
          </button>

          {/* Notifications */}
          <button
            className="relative p-2 text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
            aria-label="Notifications"
          >
            <BellIcon className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full" />
          </button>

          {/* User dropdown */}
          <Dropdown
            trigger={
              <button className="flex items-center gap-2 sm:gap-3 p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors">
                <img
                  src={user?.avatar || 'https://via.placeholder.com/32'}
                  alt={user?.name || 'User'}
                  className="w-8 h-8 rounded-full object-cover ring-2 ring-gray-200 dark:ring-gray-600"
                />
                <div className="hidden sm:block text-left">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {user?.name || 'Guest'}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">
                    {user?.role || 'Agent'}
                  </p>
                </div>
                <ChevronDownIcon className="w-4 h-4 text-gray-500 dark:text-gray-400 hidden sm:block" />
              </button>
            }
            items={userMenuItems}
            align="right"
          />
        </div>
      </div>
    </header>
  )
}
