import { Routes, Route, Navigate, Outlet } from 'react-router-dom'
import { PrivateRoute } from './PrivateRoute'
import { ROUTES } from './route-constants'

// Page imports
import { LoginPage } from '../pages/LoginPage'
import { DashboardPage } from '../pages/DashboardPage'
import { InboxPage } from '../pages/InboxPage'
import { CasesPage } from '../pages/CasesPage'
import { CaseDetailPage } from '../pages/CaseDetailPage'
import { AgentsPage } from '../pages/AgentsPage'
import { ChannelsPage } from '../pages/ChannelsPage'

// Simple Layout component inline since Layout.tsx may not exist
function Layout() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Outlet />
    </div>
  )
}

export function AppRoutes() {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path={ROUTES.LOGIN} element={<LoginPage />} />

      {/* Protected Routes */}
      <Route
        path="/"
        element={
          <PrivateRoute>
            <Layout />
          </PrivateRoute>
        }
      >
        <Route index element={<Navigate to={ROUTES.DASHBOARD} replace />} />
        <Route path={ROUTES.DASHBOARD} element={<DashboardPage />} />
        <Route path={ROUTES.INBOX} element={<InboxPage />} />
        <Route path={ROUTES.CASES} element={<CasesPage />} />
        <Route path={ROUTES.CASE_DETAIL} element={<CaseDetailPage />} />
        <Route path={ROUTES.AGENTS} element={<AgentsPage />} />
        <Route path={ROUTES.CHANNELS} element={<ChannelsPage />} />
      </Route>

      {/* 404 Fallback */}
      <Route path="*" element={<Navigate to={ROUTES.DASHBOARD} replace />} />
    </Routes>
  )
}
