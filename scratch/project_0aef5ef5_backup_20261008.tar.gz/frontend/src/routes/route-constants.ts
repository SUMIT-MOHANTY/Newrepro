export const ROUTES = {
  LOGIN: '/login',
  DASHBOARD: '/dashboard',
  INBOX: '/inbox',
  CASES: '/cases',
  CASE_DETAIL: '/cases/:id',
  AGENTS: '/agents',
  CHANNELS: '/channels',
} as const

export type RoutePath = typeof ROUTES[keyof typeof ROUTES]
