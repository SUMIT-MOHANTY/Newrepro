"""Backend application package."""
from app.main import app, lifespan

def create_app():
    """Application factory function."""
    return app

__all__ = ["app", "lifespan", "create_app"]
