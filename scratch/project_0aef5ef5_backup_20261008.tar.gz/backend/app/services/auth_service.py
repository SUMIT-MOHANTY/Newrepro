"""Authentication service with business logic."""
from datetime import datetime, timedelta
from typing import Optional, List

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.config import settings
from app.core.security import (
    verify_password,
    get_password_hash,
    create_access_token,
    create_refresh_token,
    verify_token,
)
from app.core.exceptions import (
    AuthenticationException,
    NotFoundException,
    ConflictException,
    ValidationException,
)
from app.models.user import User
from app.schemas.auth import Token
from app.schemas.user import UserCreate, UserUpdate, UserResponse


class AuthService:
    """Authentication and user management service."""

    @staticmethod
    async def authenticate_user(
        db: AsyncSession,
        email: str,
        password: str
    ) -> Optional[User]:
        """
        Authenticate a user by email and password.
        
        Args:
            db: Database session
            email: User email
            password: Plain text password
            
        Returns:
            User if authenticated, None otherwise
        """
        result = await db.execute(select(User).where(User.email == email))
        user = result.scalar_one_or_none()
        
        if not user:
            return None
            
        if not user.is_active:
            raise AuthenticationException("User account is deactivated")
            
        if not verify_password(password, user.hashed_password):
            return None
            
        return user

    @staticmethod
    async def create_user(
        db: AsyncSession,
        user_data: UserCreate
    ) -> User:
        """
        Create a new user.
        
        Args:
            db: Database session
            user_data: User creation data
            
        Returns:
            Created user
            
        Raises:
            ConflictException: If email already exists
        """
        # Check if email exists
        result = await db.execute(
            select(User).where(User.email == user_data.email)
        )
        if result.scalar_one_or_none():
            raise ConflictException(
                f"User with email '{user_data.email}' already exists",
                resource="User"
            )
        
        # Create user
        db_user = User(
            email=user_data.email,
            hashed_password=get_password_hash(user_data.password),
            full_name=user_data.full_name,
            role=user_data.role,
            is_active=user_data.is_active,
        )
        
        db.add(db_user)
        await db.commit()
        await db.refresh(db_user)
        
        return db_user

    @staticmethod
    async def get_user_by_id(
        db: AsyncSession,
        user_id: int
    ) -> User:
        """
        Get user by ID.
        
        Args:
            db: Database session
            user_id: User ID
            
        Returns:
            User
            
        Raises:
            NotFoundException: If user not found
        """
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        
        if not user:
            raise NotFoundException("User", user_id)
            
        return user

    @staticmethod
    async def get_user_by_email(
        db: AsyncSession,
        email: str
    ) -> Optional[User]:
        """
        Get user by email.
        
        Args:
            db: Database session
            email: User email
            
        Returns:
            User or None
        """
        result = await db.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    @staticmethod
    async def get_users(
        db: AsyncSession,
        skip: int = 0,
        limit: int = 100,
        role: Optional[str] = None,
        is_active: Optional[bool] = None
    ) -> List[User]:
        """
        Get list of users with optional filtering.
        
        Args:
            db: Database session
            skip: Number of records to skip
            limit: Maximum number of records to return
            role: Filter by role
            is_active: Filter by active status
            
        Returns:
            List of users
        """
        query = select(User)
        
        if role:
            query = query.where(User.role == role)
        if is_active is not None:
            query = query.where(User.is_active == is_active)
            
        query = query.offset(skip).limit(limit)
        result = await db.execute(query)
        
        return list(result.scalars().all())

    @staticmethod
    async def update_user(
        db: AsyncSession,
        user_id: int,
        user_data: UserUpdate
    ) -> User:
        """
        Update a user.
        
        Args:
            db: Database session
            user_id: User ID
            user_data: User update data
            
        Returns:
            Updated user
        """
        user = await AuthService.get_user_by_id(db, user_id)
        
        # Check email uniqueness if updating email
        if user_data.email and user_data.email != user.email:
            existing = await AuthService.get_user_by_email(db, user_data.email)
            if existing:
                raise ConflictException(
                    f"Email '{user_data.email}' is already in use",
                    resource="User"
                )
        
        # Update fields
        update_data = user_data.model_dump(exclude_unset=True)
        
        # Handle password separately
        if "password" in update_data:
            update_data["hashed_password"] = get_password_hash(update_data.pop("password"))
        
        for field, value in update_data.items():
            setattr(user, field, value)
        
        user.updated_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(user)
        
        return user

    @staticmethod
    async def delete_user(
        db: AsyncSession,
        user_id: int
    ) -> None:
        """
        Delete a user.
        
        Args:
            db: Database session
            user_id: User ID
        """
        user = await AuthService.get_user_by_id(db, user_id)
        await db.delete(user)
        await db.commit()

    @staticmethod
    def create_tokens(user: User) -> Token:
        """
        Create access and refresh tokens for a user.
        
        Args:
            user: User to create tokens for
            
        Returns:
            Token containing access_token, token_type, expires_in, refresh_token
        """
        token_data = {
            "sub": str(user.id),
            "email": user.email,
            "role": user.role,
        }
        
        access_token = create_access_token(token_data)
        refresh_token = create_refresh_token({"sub": str(user.id)})
        
        return Token(
            access_token=access_token,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
            refresh_token=refresh_token
        )

    @staticmethod
    async def refresh_access_token(
        db: AsyncSession,
        refresh_token: str
    ) -> Token:
        """
        Refresh access token using refresh token.
        
        Args:
            db: Database session
            refresh_token: JWT refresh token
            
        Returns:
            New token pair
            
        Raises:
            AuthenticationException: If refresh token is invalid
        """
        token_data = verify_token(refresh_token)
        
        if not token_data:
            raise AuthenticationException("Invalid refresh token")
        
        if token_data.type != "refresh":
            raise AuthenticationException("Invalid token type")
        
        user_id = int(token_data.sub)
        user = await AuthService.get_user_by_id(db, user_id)
        
        if not user.is_active:
            raise AuthenticationException("User account is deactivated")
        
        return AuthService.create_tokens(user)
