"""Inbox service for ingesting and processing customer communications."""
from datetime import datetime
from typing import List, Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException, ValidationException
from app.models.inbox_item import InboxItem, InboxStatus
from app.models.channel import Channel
from app.schemas.inbox import (
    InboxItemCreate,
    InboxItemUpdate,
    EmailIngestRequest,
    IngestionResponse,
)


class InboxService:
    """Service for managing inbox items and ingestion."""

    @staticmethod
    async def create_from_email(
        db: AsyncSession,
        email_data: EmailIngestRequest,
        channel_id: int,
    ) -> IngestionResponse:
        """
        Create an inbox item from an email.
        
        Args:
            db: Database session
            email_data: Email ingestion data
            channel_id: Channel ID for the email source
            
        Returns:
            IngestionResponse with the created inbox item ID
        """
        # Validate channel exists
        channel_result = await db.execute(
            select(Channel).where(Channel.id == channel_id)
        )
        channel = channel_result.scalar_one_or_none()
        if not channel:
            return IngestionResponse(
                success=False,
                message="Channel not found",
                error=f"Channel with ID {channel_id} does not exist"
            )

        if not channel.is_active:
            return IngestionResponse(
                success=False,
                message="Channel is inactive",
                error=f"Channel {channel.name} is not active"
            )

        # Generate external ID from email headers or content
        external_id = InboxService._generate_external_id(email_data)
        
        # Normalize email content
        normalized_content = InboxService._normalize_content(email_data)
        
        # Create inbox item
        inbox_item = InboxItem(
            external_id=external_id,
            channel_id=channel_id,
            raw_content=InboxService._build_raw_content(email_data),
            normalized_content=normalized_content,
            attachments=[
                {
                    "filename": att.filename,
                    "content_type": att.content_type,
                    "size": att.size,
                    "url": att.url,
                }
                for att in (email_data.attachments or [])
            ],
            received_at=email_data.received_at or datetime.utcnow(),
            status=InboxStatus.PENDING,
        )
        
        db.add(inbox_item)
        await db.commit()
        await db.refresh(inbox_item)
        
        return IngestionResponse(
            success=True,
            inbox_item_id=inbox_item.id,
            message="Email ingested successfully",
        )

    @staticmethod
    def _generate_external_id(email_data: EmailIngestRequest) -> str:
        """Generate a unique external ID for the email."""
        import hashlib
        content = f"{email_data.from_address}:{email_data.to_address}:{email_data.subject}:{email_data.received_at or datetime.utcnow().isoformat()}"
        return hashlib.sha256(content.encode()).hexdigest()[:32]

    @staticmethod
    def _normalize_content(email_data: EmailIngestRequest) -> str:
        """Normalize email content for processing."""
        # Use HTML body if available, otherwise plain text
        content = email_data.html_body or email_data.body
        
        # Basic normalization
        content = content.strip()
        
        # Remove excessive whitespace
        import re
        content = re.sub(r'\s+', ' ', content)
        
        return content

    @staticmethod
    def _build_raw_content(email_data: EmailIngestRequest) -> str:
        """Build raw content representation of the email."""
        parts = [
            f"From: {email_data.from_address}",
            f"To: {email_data.to_address}",
            f"Subject: {email_data.subject}",
            f"Received: {email_data.received_at.isoformat() if email_data.received_at else datetime.utcnow().isoformat()}",
            "",
            email_data.body,
        ]
        return "\n".join(parts)

    @staticmethod
    async def get_unprocessed(
        db: AsyncSession,
        limit: int = 100,
    ) -> List[InboxItem]:
        """
        Get unprocessed inbox items.
        
        Args:
            db: Database session
            limit: Maximum number of items to return
            
        Returns:
            List of pending inbox items
        """
        result = await db.execute(
            select(InboxItem)
            .where(InboxItem.status == InboxStatus.PENDING)
            .order_by(InboxItem.received_at.asc())
            .limit(limit)
        )
        return list(result.scalars().all())

    @staticmethod
    async def mark_processed(
        db: AsyncSession,
        inbox_item_id: int,
        case_id: Optional[int] = None,
    ) -> InboxItem:
        """
        Mark an inbox item as processed.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            case_id: Optional linked case ID
            
        Returns:
            Updated inbox item
            
        Raises:
            NotFoundException: If inbox item not found
        """
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        inbox_item = result.scalar_one_or_none()
        
        if not inbox_item:
            raise NotFoundException("InboxItem", inbox_item_id)
        
        inbox_item.status = InboxStatus.PROCESSED
        inbox_item.processed_at = datetime.utcnow()
        if case_id:
            inbox_item.case_id = case_id
        
        await db.commit()
        await db.refresh(inbox_item)
        
        return inbox_item

    @staticmethod
    async def mark_failed(
        db: AsyncSession,
        inbox_item_id: int,
        error_message: str,
    ) -> InboxItem:
        """
        Mark an inbox item as failed.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            error_message: Error message
            
        Returns:
            Updated inbox item
            
        Raises:
            NotFoundException: If inbox item not found
        """
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        inbox_item = result.scalar_one_or_none()
        
        if not inbox_item:
            raise NotFoundException("InboxItem", inbox_item_id)
        
        inbox_item.status = InboxStatus.FAILED
        inbox_item.processed_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(inbox_item)
        
        return inbox_item

    @staticmethod
    async def link_to_case(
        db: AsyncSession,
        inbox_item_id: int,
        case_id: int,
    ) -> InboxItem:
        """
        Link an inbox item to a case.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            case_id: Case ID to link to
            
        Returns:
            Updated inbox item
            
        Raises:
            NotFoundException: If inbox item not found
        """
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        inbox_item = result.scalar_one_or_none()
        
        if not inbox_item:
            raise NotFoundException("InboxItem", inbox_item_id)
        
        inbox_item.case_id = case_id
        
        await db.commit()
        await db.refresh(inbox_item)
        
        return inbox_item

    @staticmethod
    async def get_by_id(
        db: AsyncSession,
        inbox_item_id: int,
    ) -> Optional[InboxItem]:
        """
        Get an inbox item by ID.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            
        Returns:
            Inbox item or None
        """
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def update(
        db: AsyncSession,
        inbox_item_id: int,
        update_data: InboxItemUpdate,
    ) -> InboxItem:
        """
        Update an inbox item.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            update_data: Update data
            
        Returns:
            Updated inbox item
            
        Raises:
            NotFoundException: If inbox item not found
        """
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        inbox_item = result.scalar_one_or_none()
        
        if not inbox_item:
            raise NotFoundException("InboxItem", inbox_item_id)
        
        update_dict = update_data.model_dump(exclude_unset=True)
        for field, value in update_dict.items():
            setattr(inbox_item, field, value)
        
        await db.commit()
        await db.refresh(inbox_item)
        
        return inbox_item
