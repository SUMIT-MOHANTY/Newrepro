"""AI Service for case classification, response drafting, and reasoning."""
import asyncio
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Union

from app.adapters.mock_openai import MockOpenAIAdapter
from app.core.logging import get_logger
from app.models.case import Case
from app.schemas.case import (
    CaseOntology,
    ConfidenceScores,
    CustomerInfo,
    ExtractedEntity,
    IssueInfo,
    SentimentInfo,
    UrgencyInfo,
)

logger = get_logger("ai_service")


class ClassificationCategory(str, Enum):
    """Classification categories for cases."""
    BOOKING_ISSUE = "BOOKING_ISSUE"
    REFUND_REQUEST = "REFUND_REQUEST"
    ITINERARY_CHANGE = "ITINERARY_CHANGE"
    COMPLAINT = "COMPLAINT"
    GENERAL_INQUIRY = "GENERAL_INQUIRY"
    VIP_ESCALATION = "VIP_ESCALATION"


class ConfidenceThreshold(Enum):
    """Confidence thresholds for classification decisions."""
    AUTO = 0.85
    REVIEW_MIN = 0.6
    REVIEW_MAX = 0.85
    MANUAL = 0.6


@dataclass
class ClassificationResult:
    """Result of case classification."""
    category: ClassificationCategory
    confidence: float
    reasoning: str
    all_scores: Dict[str, float] = field(default_factory=dict)
    requires_review: bool = False
    suggested_action: str = ""


@dataclass
class DraftResult:
    """Result of response drafting."""
    content: str
    confidence: float
    evidence: List[str] = field(default_factory=list)
    suggested_tone: str = "professional"
    requires_approval: bool = False


@dataclass
class PlanStep:
    """Single step in an agent reasoning plan."""
    step_name: str
    description: str
    evidence: List[str] = field(default_factory=list)
    confidence: float = 0.0
    timestamp: datetime = field(default_factory=datetime.utcnow)


@dataclass
class Entity:
    """Extracted entity from text."""
    type: str
    value: str
    confidence: float = 0.0
    start_pos: Optional[int] = None
    end_pos: Optional[int] = None


@dataclass
class SentimentResult:
    """Sentiment analysis result."""
    overall: str
    score: float
    emotions: List[str] = field(default_factory=list)
    confidence: float = 0.0


class AIService:
    """AI Service for case processing and response generation."""
    
    def __init__(self, adapter: Optional[MockOpenAIAdapter] = None):
        """Initialize the AI service.
        
        Args:
            adapter: Optional LLM adapter (creates mock if None)
        """
        self.adapter = adapter or MockOpenAIAdapter()
        self.logger = logger
    
    def _get_case_text(self, case: Case) -> str:
        """Extract text content from case for analysis.
        
        Args:
            case: The case to extract text from
            
        Returns:
            Combined text string
        """
        parts = []
        
        if case.inbox_item and case.inbox_item.content:
            parts.append(case.inbox_item.content)
        
        if case.inbox_item and case.inbox_item.subject:
            parts.append(case.inbox_item.subject)
        
        if case.ontology:
            if isinstance(case.ontology, dict):
                if "issue" in case.ontology and "description" in case.ontology["issue"]:
                    parts.append(case.ontology["issue"]["description"])
        
        return " ".join(parts) if parts else ""
    
    async def classify_case(
        self,
        case: Case,
        context: Optional[Dict[str, Any]] = None
    ) -> ClassificationResult:
        """Classify a case into a category with confidence scoring.
        
        Args:
            case: The case to classify
            context: Optional additional context
            
        Returns:
            ClassificationResult with category, confidence, and reasoning
        """
        start_time = datetime.utcnow()
        case_text = self._get_case_text(case)
        
        try:
            # Get classification from adapter
            result = await self.adapter.classify(
                case_text,
                categories=[c.value for c in ClassificationCategory]
            )
            
            category = ClassificationCategory(result["category"])
            confidence = result["confidence"]
            reasoning = result["reasoning"]
            
            # Determine if review is needed based on confidence
            requires_review = confidence < ConfidenceThreshold.AUTO.value
            
            # Determine suggested action
            if confidence >= ConfidenceThreshold.AUTO.value:
                suggested_action = "auto_classify"
            elif confidence >= ConfidenceThreshold.REVIEW_MIN.value:
                suggested_action = "review_suggested"
            else:
                suggested_action = "manual_classification"
            
            classification_result = ClassificationResult(
                category=category,
                confidence=confidence,
                reasoning=reasoning,
                all_scores=result.get("all_scores", {}),
                requires_review=requires_review,
                suggested_action=suggested_action
            )
            
            # Log the operation
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            self.logger.info(
                "Case classified",
                extra={
                    "case_id": case.id,
                    "category": category.value,
                    "confidence": confidence,
                    "requires_review": requires_review,
                    "latency_ms": latency_ms,
                    "input_size": len(case_text)
                }
            )
            
            return classification_result
            
        except Exception as e:
            self.logger.error(
                "Classification failed",
                extra={
                    "case_id": case.id,
                    "error": str(e)
                }
            )
            # Return fallback classification
            return ClassificationResult(
                category=ClassificationCategory.GENERAL_INQUIRY,
                confidence=0.5,
                reasoning=f"Classification failed: {str(e)}. Defaulting to general inquiry.",
                requires_review=True,
                suggested_action="manual_classification"
            )
    
    async def draft_response(
        self,
        case: Case,
        context: Optional[Dict[str, Any]] = None
    ) -> DraftResult:
        """Draft a response for a case with context grounding.
        
        Args:
            case: The case to draft response for
            context: Optional context including case history
            
        Returns:
            DraftResult with content, confidence, and evidence
        """
        start_time = datetime.utcnow()
        case_text = self._get_case_text(case)
        
        try:
            # Build context-aware prompt
            prompt_parts = [case_text]
            
            if context:
                if "previous_responses" in context:
                    prompt_parts.append(f"Previous responses: {context['previous_responses']}")
                if "customer_history" in context:
                    prompt_parts.append(f"Customer history: {context['customer_history']}")
            
            prompt = " ".join(prompt_parts)
            
            # Generate response
            response_text = await self.adapter.generate(
                prompt=prompt,
                temperature=0.7
            )
            
            # Calculate confidence based on case data completeness
            confidence = self._calculate_response_confidence(case, context)
            
            # Build evidence chain
            evidence = []
            if case.ai_classification:
                evidence.append(f"Case classified as: {case.ai_classification}")
            if case.ontology and isinstance(case.ontology, dict):
                if "sentiment" in case.ontology:
                    evidence.append(f"Customer sentiment: {case.ontology['sentiment'].get('overall', 'unknown')}")
                if "urgency" in case.ontology:
                    evidence.append(f"Urgency level: {case.ontology['urgency'].get('level', 'unknown')}")
            
            # Determine tone based on sentiment
            suggested_tone = self._determine_tone(case)
            
            # Check if approval is needed
            requires_approval = confidence < 0.8 or case.priority.value in ["HIGH", "CRITICAL"]
            
            draft_result = DraftResult(
                content=response_text,
                confidence=confidence,
                evidence=evidence,
                suggested_tone=suggested_tone,
                requires_approval=requires_approval
            )
            
            # Log the operation
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            self.logger.info(
                "Response drafted",
                extra={
                    "case_id": case.id,
                    "confidence": confidence,
                    "requires_approval": requires_approval,
                    "latency_ms": latency_ms,
                    "input_size": len(prompt),
                    "output_size": len(response_text)
                }
            )
            
            return draft_result
            
        except Exception as e:
            self.logger.error(
                "Response drafting failed",
                extra={
                    "case_id": case.id,
                    "error": str(e)
                }
            )
            # Return fallback response
            return DraftResult(
                content="I apologize, but I'm unable to generate a response at this time. A customer service representative will review your case shortly.",
                confidence=0.3,
                evidence=["Drafting failed, using fallback"],
                requires_approval=True
            )
    
    async def explain_reasoning(
        self,
        case: Case
    ) -> List[PlanStep]:
        """Generate an explanation of the AI's reasoning process.
        
        Args:
            case: The case to explain reasoning for
            
        Returns:
            List of PlanStep objects showing the decision chain
        """
        start_time = datetime.utcnow()
        steps = []
        
        try:
            case_text = self._get_case_text(case)
            
            # Step 1: Initial Analysis
            steps.append(PlanStep(
                step_name="initial_analysis",
                description="Analyzed case content and metadata",
                evidence=[f"Content length: {len(case_text)} chars"],
                confidence=0.95
            ))
            
            # Step 2: Entity Extraction
            entities = await self.extract_entities(case_text)
            entity_evidence = [f"{e.type}: {e.value}" for e in entities[:5]]
            steps.append(PlanStep(
                step_name="entity_extraction",
                description=f"Extracted {len(entities)} entities from content",
                evidence=entity_evidence if entity_evidence else ["No key entities found"],
                confidence=0.85 if entities else 0.6
            ))
            
            # Step 3: Sentiment Analysis
            sentiment = await self.analyze_sentiment(case_text)
            steps.append(PlanStep(
                step_name="sentiment_analysis",
                description=f"Detected {sentiment.overall} sentiment with score {sentiment.score}",
                evidence=sentiment.emotions,
                confidence=sentiment.confidence
            ))
            
            # Step 4: Urgency Detection
            urgency = await self.detect_urgency(case_text)
            steps.append(PlanStep(
                step_name="urgency_detection",
                description=f"Urgency level: {urgency.level}",
                evidence=urgency.factors,
                confidence=urgency.confidence
            ))
            
            # Step 5: Classification
            classification = await self.classify_case(case)
            steps.append(PlanStep(
                step_name="classification",
                description=f"Classified as {classification.category.value}",
                evidence=[classification.reasoning],
                confidence=classification.confidence
            ))
            
            # Step 6: Decision
            decision_confidence = sum(s.confidence for s in steps) / len(steps)
            steps.append(PlanStep(
                step_name="final_decision",
                description=f"Recommended action: {classification.suggested_action}",
                evidence=[f"Overall confidence: {decision_confidence:.2f}"],
                confidence=decision_confidence
            ))
            
            # Log the operation
            latency_ms = (datetime.utcnow() - start_time).total_seconds() * 1000
            self.logger.info(
                "Reasoning explained",
                extra={
                    "case_id": case.id,
                    "steps": len(steps),
                    "latency_ms": latency_ms
                }
            )
            
        except Exception as e:
            self.logger.error(
                "Reasoning explanation failed",
                extra={
                    "case_id": case.id,
                    "error": str(e)
                }
            )
            steps.append(PlanStep(
                step_name="error",
                description=f"Failed to generate reasoning: {str(e)}",
                evidence=["Error occurred during processing"],
                confidence=0.0
            ))
        
        return steps
    
    async def extract_entities(self, text: str) -> List[Entity]:
        """Extract named entities from text.
        
        Args:
            text: Text to analyze
            
        Returns:
            List of extracted entities
        """
        try:
            raw_entities = await self.adapter.extract_entities(text)
            
            entities = []
            for e in raw_entities:
                entities.append(Entity(
                    type=e["type"],
                    value=e["value"],
                    confidence=e.get("confidence", 0.8),
                    start_pos=e.get("start_pos"),
                    end_pos=e.get("end_pos")
                ))
            
            self.logger.info(
                "Entities extracted",
                extra={
                    "count": len(entities),
                    "input_size": len(text)
                }
            )
            
            return entities
            
        except Exception as e:
            self.logger.error(
                "Entity extraction failed",
                extra={"error": str(e)}
            )
            return []
    
    async def analyze_sentiment(self, text: str) -> SentimentResult:
        """Analyze sentiment of text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Sentiment analysis result
        """
        try:
            raw_sentiment = await self.adapter.analyze_sentiment(text)
            
            result = SentimentResult(
                overall=raw_sentiment["overall"],
                score=raw_sentiment["score"],
                emotions=raw_sentiment.get("emotions", ["neutral"]),
                confidence=raw_sentiment.get("confidence", 0.75)
            )
            
            self.logger.info(
                "Sentiment analyzed",
                extra={
                    "sentiment": result.overall,
                    "score": result.score,
                    "input_size": len(text)
                }
            )
            
            return result
            
        except Exception as e:
            self.logger.error(
                "Sentiment analysis failed",
                extra={"error": str(e)}
            )
            return SentimentResult(
                overall="neutral",
                score=0.0,
                emotions=["unknown"],
                confidence=0.5
            )
    
    async def detect_urgency(self, text: str) -> Dict[str, Any]:
        """Detect urgency level in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Urgency detection result
        """
        try:
            result = await self.adapter.detect_urgency(text)
            
            self.logger.info(
                "Urgency detected",
                extra={
                    "level": result["level"],
                    "input_size": len(text)
                }
            )
            
            return result
            
        except Exception as e:
            self.logger.error(
                "Urgency detection failed",
                extra={"error": str(e)}
            )
            return {
                "level": "low",
                "factors": ["detection_failed"],
                "confidence": 0.5
            }
    
    def _calculate_response_confidence(
        self,
        case: Case,
        context: Optional[Dict[str, Any]]
    ) -> float:
        """Calculate confidence score for a drafted response.
        
        Args:
            case: The case
            context: Optional context
            
        Returns:
            Confidence score between 0.0 and 1.0
        """
        confidence = 0.7  # Base confidence
        
        # Boost confidence if we have classification
        if case.ai_classification:
            confidence += 0.1
        
        # Boost confidence if we have ontology data
        if case.ontology and isinstance(case.ontology, dict):
            confidence += 0.1
        
        # Boost confidence if we have context
        if context:
            if "previous_responses" in context:
                confidence += 0.05
            if "customer_history" in context:
                confidence += 0.05
        
        return min(confidence, 1.0)
    
    def _determine_tone(self, case: Case) -> str:
        """Determine appropriate tone for response.
        
        Args:
            case: The case
            
        Returns:
            Suggested tone string
        """
        # Check ontology for sentiment
        if case.ontology and isinstance(case.ontology, dict):
            sentiment = case.ontology.get("sentiment", {})
            if sentiment.get("overall") == "negative":
                return "empathetic"
            if sentiment.get("overall") == "positive":
                return "friendly"
        
        # Check priority
        if case.priority.value in ["HIGH", "CRITICAL"]:
            return "urgent_professional"
        
        # Check classification
        if case.ai_classification == "COMPLAINT":
            return "apologetic"
        if case.ai_classification == "VIP_ESCALATION":
            return "premium"
        
        return "professional"
    
    async def enrich_case_ontology(
        self,
        case: Case
    ) -> CaseOntology:
        """Enrich case with AI-extracted ontology data.
        
        Args:
            case: The case to enrich
            
        Returns:
            Enriched CaseOntology
        """
        case_text = self._get_case_text(case)
        
        # Run all enrichment tasks concurrently
        entities_task = self.extract_entities(case_text)
        sentiment_task = self.analyze_sentiment(case_text)
        urgency_task = self.detect_urgency(case_text)
        
        entities, sentiment, urgency = await asyncio.gather(
            entities_task,
            sentiment_task,
            urgency_task
        )
        
        # Build ontology
        ontology = CaseOntology(
            customer=CustomerInfo(),
            issue=IssueInfo(),
            sentiment=SentimentInfo(
                overall=sentiment.overall,
                score=sentiment.score,
                emotions=sentiment.emotions
            ),
            urgency=UrgencyInfo(
                level=urgency["level"],
                factors=urgency["factors"]
            ),
            entities=[
                ExtractedEntity(
                    type=e.type,
                    value=e.value,
                    confidence=e.confidence,
                    start_pos=e.start_pos,
                    end_pos=e.end_pos
                ) for e in entities
            ],
            confidence_scores=ConfidenceScores(
                sentiment=sentiment.confidence,
                urgency=urgency["confidence"],
                entities=sum(e.confidence for e in entities) / len(entities) if entities else 0.0
            ),
            extracted_at=datetime.utcnow()
        )
        
        self.logger.info(
            "Case ontology enriched",
            extra={
                "case_id": case.id,
                "entities": len(entities),
                "sentiment": sentiment.overall
            }
        )
        
        return ontology


# Singleton instance for application use
_ai_service: Optional[AIService] = None


def get_ai_service() -> AIService:
    """Get or create the AI service singleton."""
    global _ai_service
    if _ai_service is None:
        _ai_service = AIService()
    return _ai_service
