"""Case service for managing cases with ontology support."""
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any

from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.exceptions import NotFoundException, ValidationException, ConflictException
from app.models.case import Case, CaseStatus, CasePriority
from app.models.inbox_item import InboxItem, InboxStatus
from app.models.activity import Activity, ActionType
from app.models.user import User
from app.schemas.case import (
    CaseCreate,
    CaseUpdate,
    CaseOntology,
    CaseAssignmentRequest,
    CaseStatusUpdateRequest,
    OntologyUpdateRequest,
)


class CaseService:
    """Service for managing cases with ontology support."""

    @staticmethod
    def _generate_case_number() -> str:
        """Generate a unique case number in K-YYYY-NNNN format."""
        now = datetime.utcnow()
        year = now.year
        # Use timestamp-based counter for uniqueness
        counter = int((now - datetime(now.year, 1, 1)).total_seconds()) % 10000
        return f"K-{year}-{counter:04d}"

    @staticmethod
    async def create_from_inbox(
        db: AsyncSession,
        inbox_item_id: int,
        tenant_id: Optional[str] = None,
        priority: CasePriority = CasePriority.MEDIUM,
        sla_hours: int = 24,
    ) -> Case:
        """
        Create a case from an inbox item.
        
        Args:
            db: Database session
            inbox_item_id: Inbox item ID
            tenant_id: Optional tenant ID
            priority: Case priority
            sla_hours: SLA deadline in hours
            
        Returns:
            Created case
            
        Raises:
            NotFoundException: If inbox item not found
            ConflictException: If inbox item already linked to a case
        """
        # Get inbox item
        result = await db.execute(
            select(InboxItem).where(InboxItem.id == inbox_item_id)
        )
        inbox_item = result.scalar_one_or_none()
        
        if not inbox_item:
            raise NotFoundException("InboxItem", inbox_item_id)
        
        if inbox_item.case_id:
            raise ConflictException(
                f"Inbox item {inbox_item_id} is already linked to case {inbox_item.case_id}",
                resource="InboxItem"
            )
        
        # Generate case number
        case_number = CaseService._generate_case_number()
        
        # Calculate SLA deadline
        sla_deadline = datetime.utcnow() + timedelta(hours=sla_hours)
        
        # Create case
        case = Case(
            case_number=case_number,
            tenant_id=tenant_id,
            inbox_item_id=inbox_item_id,
            status=CaseStatus.NEW,
            priority=priority,
            assigned_to=None,
            ontology={},
            ai_classification=None,
            confidence_score=None,
            sla_deadline=sla_deadline,
        )
        
        db.add(case)
        await db.commit()
        await db.refresh(case)
        
        # Update inbox item status
        inbox_item.status = InboxStatus.PROCESSED
        inbox_item.processed_at = datetime.utcnow()
        inbox_item.case_id = case.id
        
        await db.commit()
        
        # Create activity log
        activity = Activity(
            case_id=case.id,
            actor_id=None,
            action=ActionType.CREATED,
            details={
                "source": "inbox_item",
                "inbox_item_id": inbox_item_id,
                "channel_id": inbox_item.channel_id,
            },
        )
        db.add(activity)
        await db.commit()
        
        return case

    @staticmethod
    async def create(
        db: AsyncSession,
        case_data: CaseCreate,
    ) -> Case:
        """
        Create a case manually.
        
        Args:
            db: Database session
            case_data: Case creation data
            
        Returns:
            Created case
        """
        case_number = CaseService._generate_case_number()
        
        # Calculate SLA based on priority
        sla_hours = {
            CasePriority.LOW: 72,
            CasePriority.MEDIUM: 24,
            CasePriority.HIGH: 8,
            CasePriority.CRITICAL: 2,
        }.get(case_data.priority, 24)
        
        sla_deadline = datetime.utcnow() + timedelta(hours=sla_hours)
        
        # Convert ontology to dict if provided
        ontology_dict = None
        if case_data.ontology:
            ontology_dict = case_data.ontology.model_dump()
        
        case = Case(
            case_number=case_number,
            tenant_id=case_data.tenant_id,
            inbox_item_id=case_data.inbox_item_id,
            status=case_data.status,
            priority=case_data.priority,
            assigned_to=case_data.assigned_to,
            ontology=ontology_dict,
            ai_classification=case_data.ai_classification,
            confidence_score=case_data.confidence_score,
            sla_deadline=case_data.sla_deadline or sla_deadline,
        )
        
        db.add(case)
        await db.commit()
        await db.refresh(case)
        
        # Create activity log
        activity = Activity(
            case_id=case.id,
            actor_id=None,
            action=ActionType.CREATED,
            details={"source": "manual"},
        )
        db.add(activity)
        await db.commit()
        
        return case

    @staticmethod
    async def get_by_id(
        db: AsyncSession,
        case_id: int,
    ) -> Optional[Case]:
        """
        Get a case by ID.
        
        Args:
            db: Database session
            case_id: Case ID
            
        Returns:
            Case or None
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_by_case_number(
        db: AsyncSession,
        case_number: str,
    ) -> Optional[Case]:
        """
        Get a case by case number.
        
        Args:
            db: Database session
            case_number: Case number
            
        Returns:
            Case or None
        """
        result = await db.execute(
            select(Case).where(Case.case_number == case_number)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_with_activity(
        db: AsyncSession,
        case_id: int,
    ) -> Optional[Dict[str, Any]]:
        """
        Get a case with its activities.
        
        Args:
            db: Database session
            case_id: Case ID
            
        Returns:
            Case with activities or None
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        case = result.scalar_one_or_none()
        
        if not case:
            return None
        
        # Get activities
        activities_result = await db.execute(
            select(Activity)
            .where(Activity.case_id == case_id)
            .order_by(desc(Activity.timestamp))
        )
        activities = list(activities_result.scalars().all())
        
        return {
            "case": case,
            "activities": activities,
        }

    @staticmethod
    async def update(
        db: AsyncSession,
        case_id: int,
        update_data: CaseUpdate,
    ) -> Case:
        """
        Update a case.
        
        Args:
            db: Database session
            case_id: Case ID
            update_data: Update data
            
        Returns:
            Updated case
            
        Raises:
            NotFoundException: If case not found
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        case = result.scalar_one_or_none()
        
        if not case:
            raise NotFoundException("Case", case_id)
        
        # Track changes for activity log
        changes = {}
        
        update_dict = update_data.model_dump(exclude_unset=True)
        
        # Handle ontology separately
        if "ontology" in update_dict and update_dict["ontology"]:
            update_dict["ontology"] = update_dict["ontology"].model_dump()
            changes["ontology"] = "updated"
        
        for field, value in update_dict.items():
            if hasattr(case, field) and getattr(case, field) != value:
                old_value = getattr(case, field)
                setattr(case, field, value)
                if field not in changes:
                    changes[field] = {"old": old_value, "new": value}
        
        case.updated_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(case)
        
        # Create activity log if there were changes
        if changes:
            activity = Activity(
                case_id=case.id,
                actor_id=None,
                action=ActionType.UPDATED,
                details=changes,
            )
            db.add(activity)
            await db.commit()
        
        return case

    @staticmethod
    async def update_ontology(
        db: AsyncSession,
        case_id: int,
        ontology_data: OntologyUpdateRequest,
    ) -> Case:
        """
        Update case ontology with AI extraction results.
        
        Args:
            db: Database session
            case_id: Case ID
            ontology_data: Ontology update data
            
        Returns:
            Updated case
            
        Raises:
            NotFoundException: If case not found
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        case = result.scalar_one_or_none()
        
        if not case:
            raise NotFoundException("Case", case_id)
        
        new_ontology = ontology_data.ontology.model_dump()
        
        if ontology_data.overwrite:
            case.ontology = new_ontology
        else:
            # Merge with existing ontology
            existing = case.ontology or {}
            existing.update(new_ontology)
            case.ontology = existing
        
        case.updated_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(case)
        
        # Create activity log
        activity = Activity(
            case_id=case.id,
            actor_id=None,
            action=ActionType.ONTOLOGY_UPDATED,
            details={
                "overwrite": ontology_data.overwrite,
                "ontology_version": new_ontology.get("version", "1.0"),
            },
        )
        db.add(activity)
        await db.commit()
        
        return case

    @staticmethod
    async def assign_agent(
        db: AsyncSession,
        case_id: int,
        assignment: CaseAssignmentRequest,
    ) -> Case:
        """
        Assign a case to an agent.
        
        Args:
            db: Database session
            case_id: Case ID
            assignment: Assignment data
            
        Returns:
            Updated case
            
        Raises:
            NotFoundException: If case or agent not found
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        case = result.scalar_one_or_none()
        
        if not case:
            raise NotFoundException("Case", case_id)
        
        # Verify agent exists
        agent_result = await db.execute(
            select(User).where(User.id == assignment.agent_id)
        )
        agent = agent_result.scalar_one_or_none()
        
        if not agent:
            raise NotFoundException("User", assignment.agent_id)
        
        old_assignee = case.assigned_to
        case.assigned_to = assignment.agent_id
        
        # Update status if it was NEW
        if case.status == CaseStatus.NEW:
            case.status = CaseStatus.ASSIGNED
        
        case.updated_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(case)
        
        # Create activity log
        activity = Activity(
            case_id=case.id,
            actor_id=assignment.agent_id,
            action=ActionType.ASSIGNED,
            details={
                "previous_assignee": old_assignee,
                "new_assignee": assignment.agent_id,
                "reason": assignment.reason,
            },
        )
        db.add(activity)
        await db.commit()
        
        return case

    @staticmethod
    async def update_status(
        db: AsyncSession,
        case_id: int,
        status_update: CaseStatusUpdateRequest,
    ) -> Case:
        """
        Update case status.
        
        Args:
            db: Database session
            case_id: Case ID
            status_update: Status update data
            
        Returns:
            Updated case
            
        Raises:
            NotFoundException: If case not found
        """
        result = await db.execute(
            select(Case).where(Case.id == case_id)
        )
        case = result.scalar_one_or_none()
        
        if not case:
            raise NotFoundException("Case", case_id)
        
        old_status = case.status
        case.status = status_update.status
        case.updated_at = datetime.utcnow()
        
        await db.commit()
        await db.refresh(case)
        
        # Determine action type
        action_map = {
            CaseStatus.RESOLVED: ActionType.RESOLVED,
            CaseStatus.CLOSED: ActionType.CLOSED,
        }
        action = action_map.get(status_update.status, ActionType.STATUS_CHANGED)
        
        # Create activity log
        activity = Activity(
            case_id=case.id,
            actor_id=None,
            action=action,
            details={
                "previous_status": old_status.value if old_status else None,
                "new_status": status_update.status.value,
                "reason": status_update.reason,
            },
        )
        db.add(activity)
        await db.commit()
        
        return case

    @staticmethod
    async def list_cases(
        db: AsyncSession,
        status: Optional[CaseStatus] = None,
        priority: Optional[CasePriority] = None,
        assigned_to: Optional[int] = None,
        tenant_id: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> List[Case]:
        """
        List cases with optional filtering.
        
        Args:
            db: Database session
            status: Filter by status
            priority: Filter by priority
            assigned_to: Filter by assignee
            tenant_id: Filter by tenant
            skip: Number of records to skip
            limit: Maximum number of records
            
        Returns:
            List of cases
        """
        query = select(Case)
        
        if status:
            query = query.where(Case.status == status)
        if priority:
            query = query.where(Case.priority == priority)
        if assigned_to:
            query = query.where(Case.assigned_to == assigned_to)
        if tenant_id:
            query = query.where(Case.tenant_id == tenant_id)
        
        query = query.order_by(desc(Case.created_at)).offset(skip).limit(limit)
        
        result = await db.execute(query)
        return list(result.scalars().all())

    @staticmethod
    async def count_cases(
        db: AsyncSession,
        status: Optional[CaseStatus] = None,
        priority: Optional[CasePriority] = None,
        assigned_to: Optional[int] = None,
        tenant_id: Optional[str] = None,
    ) -> int:
        """
        Count cases with optional filtering.
        
        Args:
            db: Database session
            status: Filter by status
            priority: Filter by priority
            assigned_to: Filter by assignee
            tenant_id: Filter by tenant
            
        Returns:
            Number of cases
        """
        query = select(func.count(Case.id))
        
        if status:
            query = query.where(Case.status == status)
        if priority:
            query = query.where(Case.priority == priority)
        if assigned_to:
            query = query.where(Case.assigned_to == assigned_to)
        if tenant_id:
            query = query.where(Case.tenant_id == tenant_id)
        
        result = await db.execute(query)
        return result.scalar()
