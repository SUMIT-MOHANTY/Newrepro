"""Authentication API endpoints."""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_current_active_user, require_admin
from app.core.exceptions import AuthenticationException
from app.core.logging import get_logger
from app.models.user import User
from app.schemas.auth import Token, LoginRequest, RefreshTokenRequest
from app.schemas.user import UserCreate, UserResponse
from app.services.auth_service import AuthService

router = APIRouter(prefix="/auth", tags=["Authentication"])
logger = get_logger("auth")


@router.post("/login", response_model=Token)
async def login(
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db)
):
    """
    OAuth2 compatible token login, get an access token for future requests.
    
    - **username**: User email address
    - **password**: User password
    """
    logger.info(f"Login attempt for user: {form_data.username}")
    
    user = await AuthService.authenticate_user(
        db, form_data.username, form_data.password
    )
    
    if not user:
        logger.warning(f"Failed login attempt for user: {form_data.username}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    logger.info(f"Successful login for user: {user.email}")
    return AuthService.create_tokens(user)


@router.post("/login/json", response_model=Token)
async def login_json(
    login_data: LoginRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    JSON-based login endpoint.
    
    - **email**: User email address
    - **password**: User password
    """
    logger.info(f"JSON login attempt for user: {login_data.email}")
    
    user = await AuthService.authenticate_user(
        db, login_data.email, login_data.password
    )
    
    if not user:
        logger.warning(f"Failed JSON login attempt for user: {login_data.email}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    logger.info(f"Successful JSON login for user: {user.email}")
    return AuthService.create_tokens(user)


@router.post("/refresh", response_model=Token)
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Refresh access token using refresh token.
    
    - **refresh_token**: Valid refresh token
    """
    logger.info("Token refresh attempt")
    
    try:
        tokens = await AuthService.refresh_access_token(
            db, refresh_data.refresh_token
        )
        logger.info("Token refresh successful")
        return tokens
    except AuthenticationException as e:
        logger.warning(f"Token refresh failed: {e.message}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )


@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user)
):
    """
    Get current authenticated user information.
    
    Returns the profile of the currently logged-in user.
    """
    return current_user


@router.post("/register", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def register_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
    admin_user: User = Depends(require_admin)
):
    """
    Register a new user (admin only).
    
    - **email**: User email address (unique)
    - **password**: User password (min 6 characters)
    - **full_name**: User full name (optional)
    - **role**: User role (admin, supervisor, agent)
    - **is_active**: Whether user is active (default: true)
    """
    logger.info(f"User registration attempt by admin {admin_user.email} for {user_data.email}")
    
    user = await AuthService.create_user(db, user_data)
    
    logger.info(f"User registered successfully: {user.email}")
    return user
