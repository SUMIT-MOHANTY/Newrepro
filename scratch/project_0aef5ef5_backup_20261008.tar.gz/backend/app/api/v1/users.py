"""User management API endpoints."""
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.api.deps import get_db, get_current_active_user, require_admin, require_supervisor
from app.core.logging import get_logger
from app.models.user import User
from app.schemas.user import UserCreate, UserResponse, UserUpdate
from app.services.auth_service import AuthService

router = APIRouter(prefix="/users", tags=["Users"])
logger = get_logger("users")


@router.get("", response_model=List[UserResponse])
async def list_users(
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(100, ge=1, le=1000, description="Maximum number of records to return"),
    role: Optional[str] = Query(None, description="Filter by role (admin, supervisor, agent)"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor)
):
    """
    List all users with optional filtering.
    
    - Requires supervisor or admin role
    - Supports pagination with skip/limit
    - Supports filtering by role and active status
    """
    logger.info(f"User list requested by {current_user.email}")
    
    users = await AuthService.get_users(
        db, skip=skip, limit=limit, role=role, is_active=is_active
    )
    
    return users


@router.get("/{user_id}", response_model=UserResponse)
async def get_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor)
):
    """
    Get a specific user by ID.
    
    - Requires supervisor or admin role
    """
    logger.info(f"User {user_id} requested by {current_user.email}")
    
    user = await AuthService.get_user_by_id(db, user_id)
    return user


@router.post("", response_model=UserResponse, status_code=status.HTTP_201_CREATED)
async def create_user(
    user_data: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Create a new user (admin only).
    
    - **email**: User email address (unique)
    - **password**: User password (min 6 characters)
    - **full_name**: User full name (optional)
    - **role**: User role (admin, supervisor, agent)
    - **is_active**: Whether user is active (default: true)
    """
    logger.info(f"User creation attempt by admin {current_user.email} for {user_data.email}")
    
    user = await AuthService.create_user(db, user_data)
    
    logger.info(f"User created successfully: {user.email}")
    return user


@router.put("/{user_id}", response_model=UserResponse)
async def update_user(
    user_id: int,
    user_data: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Update a user (admin only).
    
    All fields are optional. Only provided fields will be updated.
    """
    logger.info(f"User {user_id} update attempt by admin {current_user.email}")
    
    # Prevent self-deactivation
    if user_id == current_user.id and user_data.is_active is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot deactivate your own account"
        )
    
    user = await AuthService.update_user(db, user_id, user_data)
    
    logger.info(f"User {user_id} updated successfully")
    return user


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_admin)
):
    """
    Delete a user (admin only).
    
    - Cannot delete your own account
    """
    logger.info(f"User {user_id} deletion attempt by admin {current_user.email}")
    
    # Prevent self-deletion
    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete your own account"
        )
    
    await AuthService.delete_user(db, user_id)
    
    logger.info(f"User {user_id} deleted successfully")
    return None
