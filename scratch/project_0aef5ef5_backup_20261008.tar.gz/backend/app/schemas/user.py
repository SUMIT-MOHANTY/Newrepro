"""User Pydantic schemas."""
from datetime import datetime
from typing import Optional
from pydantic import BaseModel, Field, EmailStr, field_validator


class UserBase(BaseModel):
    """Base user schema with common fields."""
    email: EmailStr = Field(..., description="User email address")
    full_name: Optional[str] = Field(None, description="User full name")
    role: str = Field(default="agent", description="User role (admin, supervisor, agent)")
    is_active: bool = Field(default=True, description="Whether the user is active")

    @field_validator('role')
    @classmethod
    def validate_role(cls, v: str) -> str:
        """Validate role value."""
        allowed_roles = ['admin', 'supervisor', 'agent']
        if v not in allowed_roles:
            raise ValueError(f'Role must be one of: {", ".join(allowed_roles)}')
        return v


class UserCreate(UserBase):
    """User creation schema."""
    password: str = Field(
        ...,
        description="User password",
        min_length=6,
        max_length=100
    )

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "email": "agent@kuoni.demo",
                "full_name": "John Doe",
                "role": "agent",
                "is_active": True,
                "password": "securepassword123"
            }
        }


class UserUpdate(BaseModel):
    """User update schema - all fields optional."""
    email: Optional[EmailStr] = Field(None, description="User email address")
    full_name: Optional[str] = Field(None, description="User full name")
    role: Optional[str] = Field(None, description="User role (admin, supervisor, agent)")
    is_active: Optional[bool] = Field(None, description="Whether the user is active")
    password: Optional[str] = Field(
        None,
        description="User password",
        min_length=6,
        max_length=100
    )

    @field_validator('role')
    @classmethod
    def validate_role(cls, v: Optional[str]) -> Optional[str]:
        """Validate role value."""
        if v is None:
            return v
        allowed_roles = ['admin', 'supervisor', 'agent']
        if v not in allowed_roles:
            raise ValueError(f'Role must be one of: {", ".join(allowed_roles)}')
        return v

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "full_name": "John Updated",
                "role": "supervisor",
                "is_active": True
            }
        }


class UserResponse(UserBase):
    """User response schema - excludes sensitive fields."""
    id: int = Field(..., description="User ID")
    is_online: bool = Field(default=False, description="Whether the user is online")
    created_at: datetime = Field(..., description="User creation timestamp")
    updated_at: datetime = Field(..., description="User last update timestamp")

    class Config:
        """Pydantic config."""
        from_attributes = True
        json_schema_extra = {
            "example": {
                "id": 1,
                "email": "agent@kuoni.demo",
                "full_name": "John Doe",
                "role": "agent",
                "is_active": True,
                "is_online": False,
                "created_at": "2024-01-01T00:00:00",
                "updated_at": "2024-01-01T00:00:00"
            }
        }


class UserInDB(UserResponse):
    """User schema with hashed password - for internal use only."""
    hashed_password: str = Field(..., description="Hashed password")

    class Config:
        """Pydantic config."""
        from_attributes = True
