"""Pydantic schemas for Channel model."""
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


class ChannelType(str, Enum):
    """Channel type enum."""
    EMAIL = "EMAIL"
    WEBHOOK = "WEBHOOK"
    API = "API"
    SMS = "SMS"


class EmailConfig(BaseModel):
    """Email channel configuration."""
    host: str
    port: int = Field(default=993, ge=1, le=65535)
    username: str
    password: Optional[str] = None
    use_ssl: bool = True
    folder: str = "INBOX"
    poll_interval: int = Field(default=300, ge=30)  # seconds


class WebhookConfig(BaseModel):
    """Webhook channel configuration."""
    secret: Optional[str] = None
    allowed_ips: Optional[List[str]] = None
    verify_signature: bool = True


class ApiConfig(BaseModel):
    """API channel configuration."""
    api_key: Optional[str] = None
    rate_limit: int = Field(default=100, ge=1)
    allowed_origins: Optional[List[str]] = None


class ChannelConfig(BaseModel):
    """Channel configuration wrapper with type-specific validation."""
    email: Optional[EmailConfig] = None
    webhook: Optional[WebhookConfig] = None
    api: Optional[ApiConfig] = None

    @field_validator('email', 'webhook', 'api', mode='before')
    @classmethod
    def validate_config(cls, v):
        """Validate configuration data."""
        if v is None:
            return v
        return v


class ChannelBase(BaseModel):
    """Base channel schema."""
    name: str = Field(..., min_length=1, max_length=255)
    type: ChannelType
    config: Optional[Dict[str, Any]] = None
    is_active: bool = True


class ChannelCreate(ChannelBase):
    """Schema for creating a channel."""
    pass


class ChannelUpdate(BaseModel):
    """Schema for updating a channel."""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None


class ChannelResponse(ChannelBase):
    """Schema for channel response."""
    id: int
    last_poll_at: Optional[datetime] = None
    error_count: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ChannelBriefResponse(BaseModel):
    """Brief channel response for nested references."""
    id: int
    name: str
    type: ChannelType
    is_active: bool

    class Config:
        from_attributes = True


class ChannelFilter(BaseModel):
    """Schema for filtering channels."""
    type: Optional[ChannelType] = None
    is_active: Optional[bool] = None
    search: Optional[str] = None


class ChannelListResponse(BaseModel):
    """Schema for paginated channel list response."""
    items: List[ChannelResponse]
    total: int
    page: int
    page_size: int
    pages: int


class ChannelHealthResponse(BaseModel):
    """Schema for channel health status."""
    id: int
    name: str
    is_active: bool
    last_poll_at: Optional[datetime] = None
    error_count: int
    status: str  # healthy, warning, error
    message: Optional[str] = None

    class Config:
        from_attributes = True


class ChannelPollRequest(BaseModel):
    """Schema for manual channel poll request."""
    force: bool = False


class ChannelPollResponse(BaseModel):
    """Schema for channel poll response."""
    success: bool
    items_fetched: int
    message: str
