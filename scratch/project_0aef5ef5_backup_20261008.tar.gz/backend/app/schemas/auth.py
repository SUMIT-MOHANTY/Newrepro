"""Authentication Pydantic schemas."""
from typing import Optional
from pydantic import BaseModel, Field


class Token(BaseModel):
    """JWT token response schema."""
    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field(default="bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration time in seconds")
    refresh_token: Optional[str] = Field(None, description="JWT refresh token")

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "access_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
                "token_type": "bearer",
                "expires_in": 1800,
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            }
        }


class TokenPayload(BaseModel):
    """JWT token payload schema."""
    sub: str = Field(..., description="Subject (user ID)")
    email: Optional[str] = Field(None, description="User email")
    role: Optional[str] = Field(None, description="User role")
    exp: Optional[int] = Field(None, description="Expiration timestamp")
    iat: Optional[int] = Field(None, description="Issued at timestamp")
    type: Optional[str] = Field(None, description="Token type (access/refresh)")

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "sub": "1",
                "email": "user@example.com",
                "role": "agent",
                "exp": 1704067200,
                "iat": 1704065400,
                "type": "access"
            }
        }


class LoginRequest(BaseModel):
    """User login request schema."""
    email: str = Field(..., description="User email address")
    password: str = Field(..., description="User password", min_length=6)

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "email": "admin@kuoni.demo",
                "password": "admin123"
            }
        }


class RefreshTokenRequest(BaseModel):
    """Token refresh request schema."""
    refresh_token: str = Field(..., description="JWT refresh token")

    class Config:
        """Pydantic config."""
        json_schema_extra = {
            "example": {
                "refresh_token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
            }
        }
