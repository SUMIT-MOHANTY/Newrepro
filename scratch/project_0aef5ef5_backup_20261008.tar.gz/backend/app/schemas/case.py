"""Pydantic schemas for Case model with ontology support."""
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, field_validator


class CaseStatus(str, Enum):
    """Case status enum."""
    NEW = "NEW"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    PENDING = "PENDING"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class CasePriority(str, Enum):
    """Case priority enum."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class CustomerInfo(BaseModel):
    """Customer information within ontology."""
    name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    customer_id: Optional[str] = None
    segment: Optional[str] = None
    language: Optional[str] = None


class IssueInfo(BaseModel):
    """Issue information within ontology."""
    category: Optional[str] = None
    subcategory: Optional[str] = None
    description: Optional[str] = None
    booking_reference: Optional[str] = None
    travel_dates: Optional[Dict[str, str]] = None
    destination: Optional[str] = None


class SentimentInfo(BaseModel):
    """Sentiment analysis within ontology."""
    overall: Optional[str] = None  # positive, negative, neutral
    score: Optional[float] = Field(None, ge=-1.0, le=1.0)
    emotions: Optional[List[str]] = None


class UrgencyInfo(BaseModel):
    """Urgency extraction within ontology."""
    level: Optional[str] = None  # low, medium, high, critical
    factors: Optional[List[str]] = None
    deadline: Optional[str] = None


class ExtractedEntity(BaseModel):
    """Named entity extracted from content."""
    type: str
    value: str
    confidence: float = Field(..., ge=0.0, le=1.0)
    start_pos: Optional[int] = None
    end_pos: Optional[int] = None


class ConfidenceScores(BaseModel):
    """Confidence scores for AI classification."""
    category: Optional[float] = Field(None, ge=0.0, le=1.0)
    sentiment: Optional[float] = Field(None, ge=0.0, le=1.0)
    urgency: Optional[float] = Field(None, ge=0.0, le=1.0)
    entities: Optional[float] = Field(None, ge=0.0, le=1.0)
    overall: Optional[float] = Field(None, ge=0.0, le=1.0)


class CaseOntology(BaseModel):
    """Complete case ontology structure."""
    customer: Optional[CustomerInfo] = None
    issue: Optional[IssueInfo] = None
    sentiment: Optional[SentimentInfo] = None
    urgency: Optional[UrgencyInfo] = None
    entities: Optional[List[ExtractedEntity]] = None
    confidence_scores: Optional[ConfidenceScores] = None
    extracted_at: Optional[datetime] = None
    version: str = "1.0"


class CaseBase(BaseModel):
    """Base case schema."""
    tenant_id: Optional[str] = None
    status: CaseStatus = CaseStatus.NEW
    priority: CasePriority = CasePriority.MEDIUM
    assigned_to: Optional[int] = None
    ontology: Optional[CaseOntology] = None
    ai_classification: Optional[str] = None
    confidence_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    sla_deadline: Optional[datetime] = None


class CaseCreate(CaseBase):
    """Schema for creating a case."""
    inbox_item_id: Optional[int] = None


class CaseUpdate(BaseModel):
    """Schema for updating a case."""
    status: Optional[CaseStatus] = None
    priority: Optional[CasePriority] = None
    assigned_to: Optional[int] = None
    ontology: Optional[CaseOntology] = None
    ai_classification: Optional[str] = None
    confidence_score: Optional[float] = Field(None, ge=0.0, le=1.0)
    sla_deadline: Optional[datetime] = None


class CaseResponse(CaseBase):
    """Schema for case response."""
    id: int
    case_number: str
    inbox_item_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class CaseDetailResponse(CaseResponse):
    """Schema for detailed case response with related data."""
    activities: List["ActivityResponse"] = []
    inbox_item: Optional["InboxItemResponse"] = None
    assigned_agent: Optional["AgentBriefResponse"] = None


class CaseFilter(BaseModel):
    """Schema for filtering cases."""
    status: Optional[CaseStatus] = None
    priority: Optional[CasePriority] = None
    assigned_to: Optional[int] = None
    tenant_id: Optional[str] = None
    ai_classification: Optional[str] = None
    created_after: Optional[datetime] = None
    created_before: Optional[datetime] = None
    search: Optional[str] = None


class CaseListResponse(BaseModel):
    """Schema for paginated case list response."""
    items: List[CaseResponse]
    total: int
    page: int
    page_size: int
    pages: int


class CaseAssignmentRequest(BaseModel):
    """Schema for case assignment request."""
    agent_id: int
    reason: Optional[str] = None


class CaseStatusUpdateRequest(BaseModel):
    """Schema for case status update request."""
    status: CaseStatus
    reason: Optional[str] = None


class OntologyUpdateRequest(BaseModel):
    """Schema for ontology update request."""
    ontology: CaseOntology
    overwrite: bool = False


# Forward references for circular dependencies
from backend.app.schemas.inbox import InboxItemResponse
from backend.app.schemas.agent import AgentBriefResponse, ActivityResponse

CaseDetailResponse.model_rebuild()
