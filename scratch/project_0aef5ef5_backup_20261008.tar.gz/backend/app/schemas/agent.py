"""Pydantic schemas for Agent service and configuration."""
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AgentStatus(str, Enum):
    """Agent status enum."""
    OFFLINE = "OFFLINE"
    ONLINE = "ONLINE"
    BUSY = "BUSY"
    AWAY = "AWAY"


class AgentRole(str, Enum):
    """Agent role enum."""
    AGENT = "AGENT"
    SUPERVISOR = "SUPERVISOR"
    ADMIN = "ADMIN"


class AgentConfig(BaseModel):
    """Agent configuration schema."""
    max_cases: int = Field(default=10, ge=1, le=50)
    auto_assign: bool = True
    skills: List[str] = Field(default_factory=list)
    languages: List[str] = Field(default_factory=list)
    working_hours: Optional[Dict[str, Any]] = None
    notification_preferences: Dict[str, bool] = Field(default_factory=dict)


class AgentBase(BaseModel):
    """Base agent schema."""
    email: str
    full_name: Optional[str] = None
    role: AgentRole = AgentRole.AGENT
    is_active: bool = True


class AgentCreate(AgentBase):
    """Schema for creating an agent."""
    password: str = Field(..., min_length=8)
    config: Optional[AgentConfig] = None


class AgentUpdate(BaseModel):
    """Schema for updating an agent."""
    full_name: Optional[str] = None
    role: Optional[AgentRole] = None
    is_active: Optional[bool] = None
    is_online: Optional[bool] = None
    config: Optional[AgentConfig] = None


class AgentResponse(AgentBase):
    """Schema for agent response."""
    id: int
    is_online: bool = False
    config: Optional[Dict[str, Any]] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class AgentBriefResponse(BaseModel):
    """Brief agent response for nested references."""
    id: int
    email: str
    full_name: Optional[str] = None
    role: AgentRole
    is_online: bool = False

    class Config:
        from_attributes = True


class AgentFilter(BaseModel):
    """Schema for filtering agents."""
    role: Optional[AgentRole] = None
    is_active: Optional[bool] = None
    is_online: Optional[bool] = None
    search: Optional[str] = None


class AgentListResponse(BaseModel):
    """Schema for paginated agent list response."""
    items: List[AgentResponse]
    total: int
    page: int
    page_size: int
    pages: int


class AgentStats(BaseModel):
    """Agent statistics."""
    total_cases: int
    open_cases: int
    resolved_today: int
    avg_resolution_time: Optional[float] = None
    satisfaction_score: Optional[float] = None


class AgentWithStatsResponse(AgentResponse):
    """Agent response with statistics."""
    stats: Optional[AgentStats] = None


class ActivityResponse(BaseModel):
    """Schema for activity response."""
    id: int
    case_id: int
    actor_id: Optional[int] = None
    action: str
    details: Dict[str, Any]
    timestamp: datetime
    actor: Optional[AgentBriefResponse] = None

    class Config:
        from_attributes = True


class ActivityListResponse(BaseModel):
    """Schema for paginated activity list response."""
    items: List[ActivityResponse]
    total: int
    page: int
    page_size: int
    pages: int
