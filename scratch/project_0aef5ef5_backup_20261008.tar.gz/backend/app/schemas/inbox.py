"""Pydantic schemas for InboxItem model."""
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class InboxStatus(str, Enum):
    """Inbox item status enum."""
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    PROCESSED = "PROCESSED"
    FAILED = "FAILED"


class AttachmentInfo(BaseModel):
    """Attachment information."""
    filename: str
    content_type: str
    size: int
    url: Optional[str] = None


class InboxItemBase(BaseModel):
    """Base inbox item schema."""
    external_id: str
    channel_id: int
    raw_content: str
    normalized_content: Optional[str] = None
    attachments: Optional[List[AttachmentInfo]] = None


class InboxItemCreate(InboxItemBase):
    """Schema for creating an inbox item."""
    pass


class InboxItemUpdate(BaseModel):
    """Schema for updating an inbox item."""
    normalized_content: Optional[str] = None
    status: Optional[InboxStatus] = None
    processed_at: Optional[datetime] = None
    case_id: Optional[int] = None


class InboxItemResponse(InboxItemBase):
    """Schema for inbox item response."""
    id: int
    status: InboxStatus
    received_at: datetime
    processed_at: Optional[datetime] = None
    case_id: Optional[int] = None
    channel: Optional["ChannelBriefResponse"] = None

    class Config:
        from_attributes = True


class InboxItemFilter(BaseModel):
    """Schema for filtering inbox items."""
    status: Optional[InboxStatus] = None
    channel_id: Optional[int] = None
    case_id: Optional[int] = None
    received_after: Optional[datetime] = None
    received_before: Optional[datetime] = None
    search: Optional[str] = None


class InboxItemListResponse(BaseModel):
    """Schema for paginated inbox item list response."""
    items: List[InboxItemResponse]
    total: int
    page: int
    page_size: int
    pages: int


class InboxItemLinkRequest(BaseModel):
    """Schema for linking inbox item to case."""
    case_id: int


class EmailIngestRequest(BaseModel):
    """Schema for email ingestion request."""
    from_address: str
    to_address: str
    subject: str
    body: str
    html_body: Optional[str] = None
    received_at: Optional[datetime] = None
    attachments: Optional[List[AttachmentInfo]] = None
    headers: Optional[Dict[str, Any]] = None


class IngestionResponse(BaseModel):
    """Schema for ingestion response."""
    success: bool
    inbox_item_id: Optional[int] = None
    message: str
    error: Optional[str] = None


# Forward references
from backend.app.schemas.channel import ChannelBriefResponse

InboxItemResponse.model_rebuild()
