"""SQLAlchemy 2.0 setup with SQLite, session management, and base model."""
from typing import AsyncGenerator, Generator
from sqlalchemy import create_engine, event
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base, sessionmaker, Session
from sqlalchemy.pool import StaticPool

from app.config import settings


# Create declarative base for models
Base = declarative_base()


# Determine if using async SQLite
DATABASE_URL = settings.DATABASE_URL
IS_ASYNC = DATABASE_URL.startswith("sqlite+aiosqlite")

if IS_ASYNC:
    # Async SQLite setup
    engine = create_async_engine(
        DATABASE_URL,
        echo=settings.DATABASE_ECHO,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False}
    )
    
    AsyncSessionLocal = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autocommit=False,
        autoflush=False
    )
    
    async def get_db() -> AsyncGenerator[AsyncSession, None]:
        """Get async database session."""
        async with AsyncSessionLocal() as session:
            try:
                yield session
            finally:
                await session.close()
    
    async def init_db() -> None:
        """Initialize database (create tables)."""
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
    
    async def close_db() -> None:
        """Close database connections."""
        await engine.dispose()

else:
    # Sync SQLite setup (for Alembic migrations)
    engine = create_engine(
        DATABASE_URL,
        echo=settings.DATABASE_ECHO,
        poolclass=StaticPool,
        connect_args={"check_same_thread": False}
    )
    
    SessionLocal = sessionmaker(
        autocommit=False,
        autoflush=False,
        bind=engine
    )
    
    def get_db() -> Generator[Session, None, None]:
        """Get database session."""
        db = SessionLocal()
        try:
            yield db
        finally:
            db.close()
    
    def init_db() -> None:
        """Initialize database (create tables)."""
        Base.metadata.create_all(bind=engine)
    
    def close_db() -> None:
        """Close database connections."""
        engine.dispose()


# Enable foreign key support for SQLite - only for sync engine
try:
    @event.listens_for(engine, "connect")
    def set_sqlite_pragma(dbapi_conn, connection_record):
        """Enable foreign key support for SQLite."""
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()
except (AttributeError, TypeError):
    # Async engine doesn't support event listeners in the same way
    pass


class BaseModel(Base):
    """Base model with common functionality."""
    
    __abstract__ = True
    
    def to_dict(self) -> dict:
        """Convert model to dictionary."""
        return {
            column.name: getattr(self, column.name)
            for column in self.__table__.columns
        }
    
    @classmethod
    async def get_by_id(cls, db: AsyncSession, id: int):
        """Get record by ID."""
        result = await db.get(cls, id)
        return result
    
    async def save(self, db: AsyncSession):
        """Save the model instance."""
        db.add(self)
        await db.commit()
        await db.refresh(self)
        return self
    
    async def delete(self, db: AsyncSession):
        """Delete the model instance."""
        await db.delete(self)
        await db.commit()
