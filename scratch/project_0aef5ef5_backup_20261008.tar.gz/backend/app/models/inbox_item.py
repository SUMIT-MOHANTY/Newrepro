"""InboxItem model for ingested customer communications."""
from datetime import datetime
from enum import Enum as PyEnum
from typing import TYPE_CHECKING, Optional, List

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON, Enum
from sqlalchemy.orm import relationship

from backend.app.database import Base

if TYPE_CHECKING:
    from backend.app.models.case import Case
    from backend.app.models.channel import Channel


class InboxStatus(str, PyEnum):
    """Status of inbox item processing."""
    PENDING = "PENDING"
    PROCESSING = "PROCESSING"
    PROCESSED = "PROCESSED"
    FAILED = "FAILED"


class InboxItem(Base):
    """Inbox item model for ingested customer communications."""
    
    __tablename__ = "inbox_items"
    
    id = Column(Integer, primary_key=True, index=True)
    external_id = Column(String(255), unique=True, index=True, nullable=False)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    raw_content = Column(Text, nullable=False)
    normalized_content = Column(Text, nullable=True)
    attachments = Column(JSON, default=list, nullable=True)
    received_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    processed_at = Column(DateTime, nullable=True)
    status = Column(Enum(InboxStatus), default=InboxStatus.PENDING, nullable=False)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="SET NULL"), nullable=True)
    
    # Relationships
    channel = relationship("Channel", back_populates="inbox_items")
    case = relationship("Case", back_populates="inbox_item", uselist=False)
    
    def __repr__(self):
        return f"<InboxItem(id={self.id}, external_id={self.external_id}, status={self.status})>"
    
    def to_dict(self):
        """Convert inbox item to dictionary."""
        return {
            "id": self.id,
            "external_id": self.external_id,
            "channel_id": self.channel_id,
            "raw_content": self.raw_content,
            "normalized_content": self.normalized_content,
            "attachments": self.attachments or [],
            "received_at": self.received_at.isoformat() if self.received_at else None,
            "processed_at": self.processed_at.isoformat() if self.processed_at else None,
            "status": self.status.value if self.status else None,
            "case_id": self.case_id,
        }
