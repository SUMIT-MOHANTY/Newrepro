"""Activity model for audit logging."""
from datetime import datetime
from enum import Enum as PyEnum
from typing import TYPE_CHECKING, Optional

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON, Enum
from sqlalchemy.orm import relationship

from backend.app.database import Base

if TYPE_CHECKING:
    from backend.app.models.case import Case
    from backend.app.models.user import User


class ActionType(str, PyEnum):
    """Type of activity action."""
    CREATED = "CREATED"
    UPDATED = "UPDATED"
    ASSIGNED = "ASSIGNED"
    STATUS_CHANGED = "STATUS_CHANGED"
    PRIORITY_CHANGED = "PRIORITY_CHANGED"
    ONTOLOGY_UPDATED = "ONTOLOGY_UPDATED"
    COMMENT_ADDED = "COMMENT_ADDED"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"
    REOPENED = "REOPENED"


class Activity(Base):
    """Activity model for audit logging of case actions."""
    
    __tablename__ = "activities"
    
    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(Integer, ForeignKey("cases.id", ondelete="CASCADE"), nullable=False, index=True)
    actor_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    action = Column(Enum(ActionType), nullable=False)
    details = Column(JSON, default=dict, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False, index=True)
    
    # Relationships
    case = relationship("Case", back_populates="activities")
    actor = relationship("User", back_populates="activities")
    
    def __repr__(self):
        return f"<Activity(id={self.id}, case_id={self.case_id}, action={self.action})>"
    
    def to_dict(self):
        """Convert activity to dictionary."""
        return {
            "id": self.id,
            "case_id": self.case_id,
            "actor_id": self.actor_id,
            "action": self.action.value if self.action else None,
            "details": self.details or {},
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }
