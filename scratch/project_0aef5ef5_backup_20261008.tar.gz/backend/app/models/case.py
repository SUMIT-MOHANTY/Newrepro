"""Case model for customer service cases with ontology support."""
from datetime import datetime
from enum import Enum as PyEnum
from typing import TYPE_CHECKING, Optional, List

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, Float, JSON, Enum
from sqlalchemy.orm import relationship

from app.database import Base

if TYPE_CHECKING:
    from app.models.user import User
    from app.models.inbox_item import InboxItem
    from app.models.activity import Activity


class CaseStatus(str, PyEnum):
    """Status of a case."""
    NEW = "NEW"
    ASSIGNED = "ASSIGNED"
    IN_PROGRESS = "IN_PROGRESS"
    PENDING = "PENDING"
    RESOLVED = "RESOLVED"
    CLOSED = "CLOSED"


class CasePriority(str, PyEnum):
    """Priority level of a case."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class Case(Base):
    """Case model for customer service requests with ontology support."""
    
    __tablename__ = "cases"
    
    id = Column(Integer, primary_key=True, index=True)
    case_number = Column(String(50), unique=True, index=True, nullable=False)
    tenant_id = Column(String(100), index=True, nullable=True)
    inbox_item_id = Column(Integer, ForeignKey("inbox_items.id", ondelete="SET NULL"), nullable=True, index=True)
    status = Column(Enum(CaseStatus), default=CaseStatus.NEW, nullable=False, index=True)
    priority = Column(Enum(CasePriority), default=CasePriority.MEDIUM, nullable=False, index=True)
    assigned_to = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    ontology = Column(JSON, default=dict, nullable=True)
    ai_classification = Column(String(100), nullable=True)
    confidence_score = Column(Float, nullable=True)
    sla_deadline = Column(DateTime, nullable=True, index=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    inbox_item = relationship("InboxItem", back_populates="case", uselist=False)
    assigned_agent = relationship("User", back_populates="assigned_cases")
    activities = relationship("Activity", back_populates="case", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Case(id={self.id}, case_number={self.case_number}, status={self.status})>"
    
    def to_dict(self):
        """Convert case to dictionary."""
        return {
            "id": self.id,
            "case_number": self.case_number,
            "tenant_id": self.tenant_id,
            "inbox_item_id": self.inbox_item_id,
            "status": self.status.value if self.status else None,
            "priority": self.priority.value if self.priority else None,
            "assigned_to": self.assigned_to,
            "assigned_agent": self.assigned_agent.to_dict() if self.assigned_agent else None,
            "ontology": self.ontology or {},
            "ai_classification": self.ai_classification,
            "confidence_score": self.confidence_score,
            "sla_deadline": self.sla_deadline.isoformat() if self.sla_deadline else None,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
