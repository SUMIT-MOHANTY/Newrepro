"""Channel model for ingestion sources."""
from datetime import datetime
from enum import Enum as PyEnum
from typing import TYPE_CHECKING, Optional, List

from sqlalchemy import Column, Integer, String, Text, DateTime, Boolean, JSON, Enum
from sqlalchemy.orm import relationship

from backend.app.database import Base

if TYPE_CHECKING:
    from backend.app.models.inbox_item import InboxItem


class ChannelType(str, PyEnum):
    """Type of channel for ingestion."""
    EMAIL = "EMAIL"
    WEBHOOK = "WEBHOOK"
    API = "API"
    SMS = "SMS"


class Channel(Base):
    """Channel model for ingestion sources."""
    
    __tablename__ = "channels"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(255), nullable=False)
    type = Column(Enum(ChannelType), nullable=False)
    config = Column(JSON, default=dict, nullable=True)
    is_active = Column(Boolean, default=True, nullable=False)
    last_poll_at = Column(DateTime, nullable=True)
    error_count = Column(Integer, default=0, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)
    
    # Relationships
    inbox_items = relationship("InboxItem", back_populates="channel", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<Channel(id={self.id}, name={self.name}, type={self.type})>"
    
    def to_dict(self):
        """Convert channel to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "type": self.type.value if self.type else None,
            "config": self.config or {},
            "is_active": self.is_active,
            "last_poll_at": self.last_poll_at.isoformat() if self.last_poll_at else None,
            "error_count": self.error_count,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }
