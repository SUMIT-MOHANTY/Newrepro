"""Custom exception hierarchy for domain errors."""
from typing import Any, Dict, Optional
from fastapi import HTTPException, status
import logging


class DomainException(Exception):
    """Base exception for all domain errors."""
    
    def __init__(
        self,
        message: str,
        code: str = "DOMAIN_ERROR",
        details: Optional[Dict[str, Any]] = None
    ):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)


class NotFoundException(DomainException):
    """Exception raised when a resource is not found."""
    
    def __init__(
        self,
        resource: str,
        identifier: Any,
        message: Optional[str] = None
    ):
        msg = message or f"{resource} with identifier '{identifier}' not found"
        super().__init__(
            message=msg,
            code="NOT_FOUND",
            details={"resource": resource, "identifier": str(identifier)}
        )


class ValidationException(DomainException):
    """Exception raised when validation fails."""
    
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        super().__init__(
            message=message,
            code="VALIDATION_ERROR",
            details={"field": field, **(details or {})}
        )


class AuthenticationException(DomainException):
    """Exception raised when authentication fails."""
    
    def __init__(self, message: str = "Authentication failed"):
        super().__init__(
            message=message,
            code="AUTHENTICATION_ERROR"
        )


class AuthorizationException(DomainException):
    """Exception raised when authorization fails."""
    
    def __init__(self, message: str = "Insufficient permissions"):
        super().__init__(
            message=message,
            code="AUTHORIZATION_ERROR"
        )


class ConflictException(DomainException):
    """Exception raised when there's a resource conflict."""
    
    def __init__(self, message: str, resource: Optional[str] = None):
        super().__init__(
            message=message,
            code="CONFLICT",
            details={"resource": resource}
        )


class ExternalServiceException(DomainException):
    """Exception raised when an external service call fails."""
    
    def __init__(
        self,
        service: str,
        message: str,
        status_code: Optional[int] = None
    ):
        super().__init__(
            message=message,
            code="EXTERNAL_SERVICE_ERROR",
            details={"service": service, "status_code": status_code}
        )


def domain_exception_to_http(exception: DomainException) -> HTTPException:
    """Convert a domain exception to an HTTP exception."""
    status_map = {
        "NOT_FOUND": status.HTTP_404_NOT_FOUND,
        "VALIDATION_ERROR": status.HTTP_422_UNPROCESSABLE_ENTITY,
        "AUTHENTICATION_ERROR": status.HTTP_401_UNAUTHORIZED,
        "AUTHORIZATION_ERROR": status.HTTP_403_FORBIDDEN,
        "CONFLICT": status.HTTP_409_CONFLICT,
        "EXTERNAL_SERVICE_ERROR": status.HTTP_502_BAD_GATEWAY,
    }
    
    http_status = status_map.get(exception.code, status.HTTP_500_INTERNAL_SERVER_ERROR)
    
    return HTTPException(
        status_code=http_status,
        detail={
            "message": exception.message,
            "code": exception.code,
            "details": exception.details
        }
    )
