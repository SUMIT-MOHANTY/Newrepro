"""Structured JSON logging with correlation IDs."""
import json
import logging
import sys
import uuid
from contextvars import ContextVar
from datetime import datetime
from typing import Any, Dict, Optional

# Context variable for correlation ID
correlation_id: ContextVar[Optional[str]] = ContextVar(
    "correlation_id",
    default=None
)


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON."""
        log_data: Dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        
        # Add correlation ID if present
        cid = correlation_id.get()
        if cid:
            log_data["correlation_id"] = cid
        
        # Add exception info if present
        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)
        
        # Add any extra fields
        for key, value in record.__dict__.items():
            if key not in (
                "name", "msg", "args", "levelname", "levelno",
                "pathname", "filename", "module", "exc_info",
                "exc_text", "stack_info", "lineno", "funcName",
                "created", "msecs", "relativeCreated", "thread",
                "threadName", "processName", "process", "message",
                "asctime", "correlation_id"
            ):
                log_data[key] = value
        
        return json.dumps(log_data, default=str)


class CorrelationIdFilter(logging.Filter):
    """Filter that adds correlation ID to log records."""
    
    def filter(self, record: logging.LogRecord) -> bool:
        """Add correlation ID to the record."""
        cid = correlation_id.get()
        record.correlation_id = cid
        return True


def get_correlation_id() -> str:
    """Get or create a correlation ID."""
    cid = correlation_id.get()
    if cid is None:
        cid = str(uuid.uuid4())
        correlation_id.set(cid)
    return cid


def set_correlation_id(cid: Optional[str] = None) -> str:
    """Set a correlation ID."""
    if cid is None:
        cid = str(uuid.uuid4())
    correlation_id.set(cid)
    return cid


def clear_correlation_id() -> None:
    """Clear the correlation ID."""
    correlation_id.set(None)


def configure_logging(
    level: str = "INFO",
    json_format: bool = True
) -> None:
    """
    Configure structured logging.
    
    Args:
        level: The logging level
        json_format: Whether to use JSON formatting
    """
    # Create root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))
    
    # Remove existing handlers
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # Create console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(getattr(logging, level.upper()))
    
    # Add correlation ID filter
    console_handler.addFilter(CorrelationIdFilter())
    
    # Set formatter
    if json_format:
        formatter = JSONFormatter()
    else:
        formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - "
            "[%(correlation_id)s] - %(message)s"
        )
    
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)
    
    # Configure uvicorn loggers
    for logger_name in ["uvicorn", "uvicorn.access", "uvicorn.error"]:
        uvicorn_logger = logging.getLogger(logger_name)
        uvicorn_logger.handlers = []
        uvicorn_logger.propagate = True


def get_logger(name: str) -> logging.Logger:
    """Get a logger with the given name."""
    return logging.getLogger(name)


# Convenience functions for common log levels
def debug(msg: str, **kwargs: Any) -> None:
    """Log a debug message."""
    logger = get_logger("app")
    logger.debug(msg, extra=kwargs)


def info(msg: str, **kwargs: Any) -> None:
    """Log an info message."""
    logger = get_logger("app")
    logger.info(msg, extra=kwargs)


def warning(msg: str, **kwargs: Any) -> None:
    """Log a warning message."""
    logger = get_logger("app")
    logger.warning(msg, extra=kwargs)


def error(msg: str, **kwargs: Any) -> None:
    """Log an error message."""
    logger = get_logger("app")
    logger.error(msg, extra=kwargs)


def critical(msg: str, **kwargs: Any) -> None:
    """Log a critical message."""
    logger = get_logger("app")
    logger.critical(msg, extra=kwargs)
