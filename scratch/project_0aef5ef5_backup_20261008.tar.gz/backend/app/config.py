"""Pydantic Settings with environment variable support."""
from functools import lru_cache
from typing import List, Optional
from pydantic_settings import BaseSettings
from pydantic import Field
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Application
    APP_NAME: str = Field(default="ServiceOps API", description="Application name")
    APP_VERSION: str = Field(default="1.0.0", description="Application version")
    DEBUG: bool = Field(default=False, description="Debug mode")
    ENVIRONMENT: str = Field(default="development", description="Environment name")
    
    # Server
    HOST: str = Field(default="0.0.0.0", description="Server host")
    PORT: int = Field(default=8000, description="Server port")
    
    # Database
    DATABASE_URL: str = Field(
        default="sqlite:///./serviceops.db",
        description="Database connection URL"
    )
    DATABASE_ECHO: bool = Field(default=False, description="Echo SQL queries")
    
    # Security
    SECRET_KEY: str = Field(
        default="your-secret-key-change-in-production",
        description="Secret key for JWT signing"
    )
    ALGORITHM: str = Field(default="HS256", description="JWT algorithm")
    ACCESS_TOKEN_EXPIRE_MINUTES: int = Field(
        default=30,
        description="Access token expiration in minutes"
    )
    REFRESH_TOKEN_EXPIRE_DAYS: int = Field(
        default=7,
        description="Refresh token expiration in days"
    )
    
    # CORS
    CORS_ORIGINS: List[str] = Field(
        default=["http://localhost:3000", "http://localhost:5173"],
        description="Allowed CORS origins"
    )
    CORS_ALLOW_CREDENTIALS: bool = Field(default=True)
    CORS_ALLOW_METHODS: List[str] = Field(default=["*"])
    CORS_ALLOW_HEADERS: List[str] = Field(default=["*"])
    
    # Logging
    LOG_LEVEL: str = Field(default="INFO", description="Logging level")
    LOG_JSON_FORMAT: bool = Field(default=True, description="Use JSON logging format")
    
    # API
    API_PREFIX: str = Field(default="/api/v1", description="API prefix")
    API_TITLE: str = Field(default="ServiceOps API", description="API title")
    API_DESCRIPTION: str = Field(
        default="AI-powered customer service operations platform",
        description="API description"
    )
    
    # AI Service
    AI_SERVICE_URL: Optional[str] = Field(
        default=None,
        description="AI service URL"
    )
    AI_SERVICE_TIMEOUT: int = Field(
        default=30,
        description="AI service timeout in seconds"
    )
    
    # SSE
    SSE_KEEP_ALIVE_INTERVAL: int = Field(
        default=30,
        description="SSE keep-alive interval in seconds"
    )
    
    class Config:
        """Pydantic config."""
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True
        extra = "ignore"


@lru_cache()
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()


# Global settings instance
settings = get_settings()
