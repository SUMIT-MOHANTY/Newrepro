"""Mock OpenAI adapter for testing and development."""
import asyncio
import hashlib
import json
import random
from typing import Any, Dict, List, Optional

from app.adapters.base import BaseLLMAdapter


class MockOpenAIAdapter(BaseLLMAdapter):
    """Mock OpenAI adapter with deterministic responses.
    
    Provides realistic travel industry responses based on input content hashing.
    Simulates latency between 200-800ms for realistic behavior.
    """
    
    # Classification categories
    CATEGORIES = [
        "BOOKING_ISSUE",
        "REFUND_REQUEST",
        "ITINERARY_CHANGE",
        "COMPLAINT",
        "GENERAL_INQUIRY",
        "VIP_ESCALATION"
    ]
    
    # Travel industry keywords for classification
    CATEGORY_KEYWORDS = {
        "BOOKING_ISSUE": ["booking", "reservation", "confirm", "double booked", "cancelled", "error"],
        "REFUND_REQUEST": ["refund", "money back", "chargeback", "reimburse", "compensation"],
        "ITINERARY_CHANGE": ["change", "modify", "reschedule", "flight change", "date change"],
        "COMPLAINT": ["complaint", "unhappy", "disappointed", "terrible", "worst", "awful"],
        "GENERAL_INQUIRY": ["question", "information", "inquiry", "help", "how to"],
        "VIP_ESCALATION": ["vip", "premium", "executive", "urgent", "escalate", "manager"]
    }
    
    # Response templates for different categories
    RESPONSE_TEMPLATES = {
        "BOOKING_ISSUE": [
            "I understand you're experiencing issues with your booking. Let me review your reservation details and help resolve this promptly.",
            "I apologize for the booking inconvenience. I'll investigate your reservation and provide a solution within 24 hours.",
            "Thank you for bringing this booking matter to our attention. I'm escalating this to our reservations team for immediate review."
        ],
        "REFUND_REQUEST": [
            "I've received your refund request and will process this according to our policy. You should receive confirmation within 3-5 business days.",
            "I understand your need for a refund. I'm reviewing your case and will provide a resolution shortly.",
            "Your refund request has been logged. Our billing team will assess eligibility and contact you with next steps."
        ],
        "ITINERARY_CHANGE": [
            "I can help you modify your itinerary. Let me check availability for your preferred dates and options.",
            "Thank you for requesting changes to your travel plans. I'll review the modification fees and alternatives for you.",
            "I understand you need to adjust your itinerary. I'm checking our flexible change policy for your booking."
        ],
        "COMPLAINT": [
            "I sincerely apologize for your experience. Your feedback is valuable, and I'm personally ensuring this is addressed.",
            "Thank you for sharing your concerns. I understand your frustration and am committed to making this right.",
            "I apologize that we didn't meet your expectations. I'm escalating this to ensure proper resolution and service recovery."
        ],
        "GENERAL_INQUIRY": [
            "Thank you for your inquiry. I'd be happy to provide the information you need about our services.",
            "I appreciate your interest. Here are the details you requested regarding your travel options.",
            "Thank you for reaching out. I'm here to help with any questions about your travel experience."
        ],
        "VIP_ESCALATION": [
            "As a valued premium customer, your request is being handled with priority. A specialist will contact you within 2 hours.",
            "Thank you for your patience. Your VIP status ensures expedited handling, and I'm personally overseeing your case.",
            "I understand the urgency of your situation. Your case has been escalated to our executive support team."
        ]
    }
    
    def __init__(self, model_name: Optional[str] = None, **kwargs: Any):
        """Initialize the mock adapter.
        
        Args:
            model_name: The model name to simulate
            **kwargs: Additional configuration
        """
        super().__init__(model_name or "gpt-4-mock", **kwargs)
        self.latency_min = kwargs.get("latency_min_ms", 200)
        self.latency_max = kwargs.get("latency_max_ms", 800)
    
    def _get_content_hash(self, content: str) -> str:
        """Generate deterministic hash from content.
        
        Args:
            content: Input content string
            
        Returns:
            Hash string for deterministic selection
        """
        return hashlib.md5(content.encode()).hexdigest()
    
    def _get_hash_based_value(self, content: str, min_val: float = 0.0, max_val: float = 1.0) -> float:
        """Get a deterministic value from content hash.
        
        Args:
            content: Input content string
            min_val: Minimum value
            max_val: Maximum value
            
        Returns:
            Deterministic float value
        """
        hash_val = int(self._get_content_hash(content)[:8], 16)
        normalized = hash_val / 0xFFFFFFFF
        return min_val + (normalized * (max_val - min_val))
    
    def _classify_content(self, content: str) -> tuple[str, float]:
        """Classify content based on keywords.
        
        Args:
            content: Input content to classify
            
        Returns:
            Tuple of (category, confidence_score)
        """
        content_lower = content.lower()
        scores = {}
        
        for category, keywords in self.CATEGORY_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in content_lower)
            scores[category] = score
        
        total_score = sum(scores.values())
        if total_score == 0:
            # Default to GENERAL_INQUIRY with medium confidence
            return "GENERAL_INQUIRY", 0.65
        
        best_category = max(scores, key=scores.get)
        confidence = min(0.95, 0.5 + (scores[best_category] / max(scores.values()) * 0.5))
        
        return best_category, confidence
    
    async def _simulate_latency(self) -> None:
        """Simulate realistic API latency."""
        latency_ms = random.randint(self.latency_min, self.latency_max)
        await asyncio.sleep(latency_ms / 1000)
    
    async def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        **kwargs: Any
    ) -> str:
        """Generate text completion.
        
        Args:
            prompt: The input prompt
            max_tokens: Maximum tokens to generate (ignored in mock)
            temperature: Sampling temperature (ignored in mock)
            **kwargs: Additional parameters
            
        Returns:
            Generated text response
        """
        await self._simulate_latency()
        
        # Determine category from prompt
        category, _ = self._classify_content(prompt)
        
        # Select response template based on hash
        hash_val = self._get_content_hash(prompt)
        templates = self.RESPONSE_TEMPLATES[category]
        template_index = int(hash_val, 16) % len(templates)
        
        return templates[template_index]
    
    async def chat(
        self,
        messages: List[Dict[str, str]],
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        **kwargs: Any
    ) -> str:
        """Generate chat completion.
        
        Args:
            messages: List of message dicts
            max_tokens: Maximum tokens (ignored in mock)
            temperature: Sampling temperature (ignored in mock)
            **kwargs: Additional parameters
            
        Returns:
            Generated chat response
        """
        await self._simulate_latency()
        
        # Combine messages for classification
        combined = " ".join([m.get("content", "") for m in messages])
        category, _ = self._classify_content(combined)
        
        # Select response based on hash
        hash_val = self._get_content_hash(combined)
        templates = self.RESPONSE_TEMPLATES[category]
        template_index = int(hash_val, 16) % len(templates)
        
        return templates[template_index]
    
    async def embed(
        self,
        text: str,
        **kwargs: Any
    ) -> List[float]:
        """Generate mock embeddings.
        
        Args:
            text: Text to embed
            **kwargs: Additional parameters
            
        Returns:
            List of 1536 float values (OpenAI embedding dimension)
        """
        await self._simulate_latency()
        
        # Generate deterministic embedding from text hash
        hash_val = self._get_content_hash(text)
        random.seed(hash_val)
        
        # Generate 1536-dimensional embedding (OpenAI standard)
        embedding = [random.gauss(0, 0.1) for _ in range(1536)]
        
        # Normalize to unit length
        magnitude = sum(x ** 2 for x in embedding) ** 0.5
        embedding = [x / magnitude for x in embedding]
        
        return embedding
    
    async def classify(
        self,
        text: str,
        categories: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """Classify text into categories.
        
        Args:
            text: Text to classify
            categories: Optional list of categories (uses defaults if None)
            
        Returns:
            Classification result with category, confidence, and reasoning
        """
        await self._simulate_latency()
        
        categories = categories or self.CATEGORIES
        category, confidence = self._classify_content(text)
        
        # Generate reasoning based on detected keywords
        content_lower = text.lower()
        detected_keywords = []
        for kw in self.CATEGORY_KEYWORDS.get(category, []):
            if kw in content_lower:
                detected_keywords.append(kw)
        
        reasoning = f"Detected keywords: {', '.join(detected_keywords)}. " if detected_keywords else ""
        reasoning += f"Content patterns match {category} classification criteria."
        
        return {
            "category": category,
            "confidence": confidence,
            "reasoning": reasoning,
            "all_scores": {cat: self._get_hash_based_value(text + cat) for cat in categories}
        }
    
    async def extract_entities(self, text: str) -> List[Dict[str, Any]]:
        """Extract named entities from text.
        
        Args:
            text: Text to analyze
            
        Returns:
            List of extracted entities
        """
        await self._simulate_latency()
        
        entities = []
        text_lower = text.lower()
        
        # Simple pattern matching for travel entities
        entity_patterns = {
            "BOOKING_REFERENCE": [r"booking ref[:\s]*(\w+)", r"reference[:\s]*(\w+)", r"confirmation[:\s]*(\w+)"],
            "DATE": [r"\d{1,2}[/-]\d{1,2}[/-]\d{2,4}", r"\d{4}-\d{2}-\d{2}"],
            "EMAIL": [r"[\w.-]+@[\w.-]+\.\w+"],
            "PHONE": [r"\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}"],
            "FLIGHT_NUMBER": [r"[A-Z]{2}\d{3,4}"],
            "DESTINATION": ["paris", "london", "tokyo", "new york", "dubai", "singapore", "bali"]
        }
        
        import re
        
        for entity_type, patterns in entity_patterns.items():
            for pattern in patterns:
                if entity_type == "DESTINATION":
                    # Simple keyword matching for destinations
                    for dest in patterns:
                        if dest in text_lower:
                            start = text_lower.find(dest)
                            entities.append({
                                "type": entity_type,
                                "value": dest.title(),
                                "confidence": 0.85,
                                "start_pos": start,
                                "end_pos": start + len(dest)
                            })
                else:
                    # Regex matching
                    matches = re.finditer(pattern, text, re.IGNORECASE)
                    for match in matches:
                        entities.append({
                            "type": entity_type,
                            "value": match.group(),
                            "confidence": 0.9,
                            "start_pos": match.start(),
                            "end_pos": match.end()
                        })
        
        return entities
    
    async def analyze_sentiment(self, text: str) -> Dict[str, Any]:
        """Analyze sentiment of text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Sentiment analysis result
        """
        await self._simulate_latency()
        
        text_lower = text.lower()
        
        # Simple sentiment analysis based on keywords
        positive_words = ["good", "great", "excellent", "happy", "satisfied", "thank", "appreciate", "love"]
        negative_words = ["bad", "terrible", "awful", "worst", "hate", "disappointed", "angry", "frustrated", "unhappy"]
        
        positive_count = sum(1 for w in positive_words if w in text_lower)
        negative_count = sum(1 for w in negative_words if w in text_lower)
        
        if negative_count > positive_count:
            sentiment = "negative"
            score = -0.3 - (0.4 * min(negative_count / 3, 1.0))
        elif positive_count > negative_count:
            sentiment = "positive"
            score = 0.3 + (0.4 * min(positive_count / 3, 1.0))
        else:
            sentiment = "neutral"
            score = self._get_hash_based_value(text, -0.2, 0.2)
        
        emotions = []
        if "angry" in text_lower or "furious" in text_lower:
            emotions.append("anger")
        if "worried" in text_lower or "concerned" in text_lower:
            emotions.append("anxiety")
        if "excited" in text_lower:
            emotions.append("excitement")
        if "happy" in text_lower or "pleased" in text_lower:
            emotions.append("happiness")
        
        return {
            "overall": sentiment,
            "score": round(score, 2),
            "emotions": emotions if emotions else ["neutral"],
            "confidence": 0.75 + (abs(score) * 0.2)
        }
    
    async def detect_urgency(self, text: str) -> Dict[str, Any]:
        """Detect urgency level in text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Urgency detection result
        """
        await self._simulate_latency()
        
        text_lower = text.lower()
        
        urgency_keywords = {
            "critical": ["urgent", "emergency", "asap", "immediately", "critical", "life threatening"],
            "high": ["today", "soon", "quickly", "deadline", "tomorrow"],
            "medium": ["this week", "in a few days"],
            "low": []
        }
        
        factors = []
        level = "low"
        
        for lvl, keywords in urgency_keywords.items():
            for kw in keywords:
                if kw in text_lower:
                    factors.append(kw)
                    if urgency_keywords.keys().index(lvl) > urgency_keywords.keys().index(level):
                        level = lvl
        
        # Check for VIP indicators
        if any(w in text_lower for w in ["vip", "premium", "executive"]):
            level = "critical"
            factors.append("vip_customer")
        
        return {
            "level": level,
            "factors": factors if factors else ["routine_inquiry"],
            "confidence": 0.8 if factors else 0.6
        }
