"""Base LLM Adapter interface for AI service."""
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional


class BaseLLMAdapter(ABC):
    """Abstract base class for LLM adapters.
    
    This interface defines the contract for all LLM adapters,
    including text completion, chat completion, and embeddings.
    """
    
    def __init__(self, model_name: Optional[str] = None, **kwargs: Any):
        """Initialize the adapter.
        
        Args:
            model_name: The model name/identifier to use
            **kwargs: Additional configuration options
        """
        self.model_name = model_name or "default"
        self.config = kwargs
    
    @abstractmethod
    async def generate(
        self,
        prompt: str,
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        **kwargs: Any
    ) -> str:
        """Generate text completion from a prompt.
        
        Args:
            prompt: The input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0-2.0)
            **kwargs: Additional generation parameters
            
        Returns:
            Generated text string
        """
        pass
    
    @abstractmethod
    async def chat(
        self,
        messages: List[Dict[str, str]],
        max_tokens: Optional[int] = None,
        temperature: float = 0.7,
        **kwargs: Any
    ) -> str:
        """Generate chat completion from messages.
        
        Args:
            messages: List of message dicts with 'role' and 'content' keys
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0.0-2.0)
            **kwargs: Additional generation parameters
            
        Returns:
            Generated response text
        """
        pass
    
    @abstractmethod
    async def embed(
        self,
        text: str,
        **kwargs: Any
    ) -> List[float]:
        """Generate embeddings for text.
        
        Args:
            text: The text to embed
            **kwargs: Additional embedding parameters
            
        Returns:
            List of embedding values
        """
        pass
    
    async def health_check(self) -> bool:
        """Check if the adapter is healthy and available.
        
        Returns:
            True if healthy, False otherwise
        """
        return True
