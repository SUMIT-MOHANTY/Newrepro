"""FastAPI application entry with router aggregation."""
import json
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import AsyncGenerator

from fastapi import FastAPI, Request, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db, close_db, IS_ASYNC
from app.core.logging import configure_logging, get_correlation_id, set_correlation_id, get_logger
from app.core.exceptions import DomainException, domain_exception_to_http

# Configure logging - already configured in logging module
logger = get_logger("app")


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator:
    """Application lifespan handler."""
    # Startup
    logger.info(
        "Starting application",
        extra={"app_name": settings.APP_NAME, "version": settings.APP_VERSION}
    )
    
    if IS_ASYNC:
        await init_db()
    else:
        from app.database import init_db as sync_init_db
        sync_init_db()
    
    logger.info("Database initialized")
    
    # Emit API contract after app is fully initialized
    emit_api_contract()
    
    yield
    
    # Shutdown
    logger.info("Shutting down application")
    if IS_ASYNC:
        await close_db()
    else:
        from app.database import close_db as sync_close_db
        sync_close_db()


# Create FastAPI application
app = FastAPI(
    title=settings.API_TITLE,
    description=settings.API_DESCRIPTION,
    version=settings.APP_VERSION,
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url="/redoc" if settings.DEBUG else None,
    openapi_url="/openapi.json" if settings.DEBUG else None,
    lifespan=lifespan
)


# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=settings.CORS_ALLOW_CREDENTIALS,
    allow_methods=settings.CORS_ALLOW_METHODS,
    allow_headers=settings.CORS_ALLOW_HEADERS,
)


# Add correlation ID middleware
@app.middleware("http")
async def correlation_id_middleware(request: Request, call_next):
    """Add correlation ID to each request."""
    # Get or create correlation ID
    cid = request.headers.get("X-Correlation-ID")
    set_correlation_id(cid)
    
    response = await call_next(request)
    
    # Add correlation ID to response
    response.headers["X-Correlation-ID"] = get_correlation_id()
    
    return response


# Add logging middleware
@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    """Log requests and responses."""
    start_time = datetime.utcnow()
    
    logger.info(
        "Request started",
        extra={
            "method": request.method,
            "path": request.url.path,
            "query": str(request.query_params),
            "client": request.client.host if request.client else None
        }
    )
    
    response = await call_next(request)
    
    duration = (datetime.utcnow() - start_time).total_seconds()
    
    logger.info(
        "Request completed",
        extra={
            "method": request.method,
            "path": request.url.path,
            "status_code": response.status_code,
            "duration_ms": duration * 1000
        }
    )
    
    return response


# Exception handlers
@app.exception_handler(DomainException)
async def domain_exception_handler(request: Request, exc: DomainException):
    """Handle domain exceptions."""
    http_exc = domain_exception_to_http(exc)
    logger.error(
        "Domain exception",
        extra={
            "code": exc.code,
            "message": exc.message,
            "details": exc.details,
            "path": request.url.path
        }
    )
    return JSONResponse(
        status_code=http_exc.status_code,
        content=http_exc.detail
    )


@app.exception_handler(Exception)
async def general_exception_handler(request: Request, exc: Exception):
    """Handle general exceptions."""
    logger.exception("Unhandled exception", extra={"path": request.url.path})
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "message": "Internal server error",
            "code": "INTERNAL_ERROR"
        }
    )


# Health check endpoints
@app.get("/health", tags=["Health"])
async def health_check():
    """Basic health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": settings.APP_VERSION
    }


@app.get("/api/health", tags=["Health"])
async def api_health_check():
    """API health check endpoint."""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": settings.APP_VERSION,
        "environment": settings.ENVIRONMENT
    }


@app.get("/api/health/db", tags=["Health"])
async def db_health_check():
    """Database health check endpoint."""
    try:
        # Simple DB connectivity check
        from app.database import engine
        from sqlalchemy import text
        
        if IS_ASYNC:
            async with engine.connect() as conn:
                result = await conn.execute(text("SELECT 1"))
                await result.fetchone()
        else:
            with engine.connect() as conn:
                result = conn.execute(text("SELECT 1"))
                result.fetchone()
        
        return {
            "status": "healthy",
            "database": "connected",
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        logger.error("Database health check failed", extra={"error": str(e)})
        return JSONResponse(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            content={
                "status": "unhealthy",
                "database": "disconnected",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
        )


# Root endpoint
@app.get("/", tags=["Root"])
async def root():
    """Root endpoint."""
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "docs": "/docs" if settings.DEBUG else None
    }


# Emit API contract on startup
def emit_api_contract():
    """Generate and save API contract JSON."""
    try:
        contract_path = Path("/workspace/.agent/contracts/api_contract.json")
        contract_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Get OpenAPI schema
        openapi_schema = app.openapi()
        
        # Extract key information
        contract = {
            "updated_at": datetime.utcnow().isoformat(),
            "title": openapi_schema.get("info", {}).get("title", ""),
            "version": openapi_schema.get("info", {}).get("version", ""),
            "description": openapi_schema.get("info", {}).get("description", ""),
            "routes": [],
            "models": []
        }
        
        # Extract routes
        for path, methods in openapi_schema.get("paths", {}).items():
            for method, details in methods.items():
                if method in ["get", "post", "put", "delete", "patch"]:
                    route_info = {
                        "method": method.upper(),
                        "path": path,
                        "summary": details.get("summary", ""),
                        "tags": details.get("tags", []),
                        "parameters": [],
                        "request_body": None,
                        "responses": {}
                    }
                    
                    # Extract parameters
                    for param in details.get("parameters", []):
                        route_info["parameters"].append({
                            "name": param.get("name"),
                            "in": param.get("in"),
                            "required": param.get("required", False),
                            "type": param.get("schema", {}).get("type", "string")
                        })
                    
                    # Extract request body
                    request_body = details.get("requestBody", {})
                    if request_body:
                        content = request_body.get("content", {})
                        if "application/json" in content:
                            route_info["request_body"] = content["application/json"].get("schema", {})
                    
                    # Extract responses
                    for status_code, response in details.get("responses", {}).items():
                        route_info["responses"][status_code] = {
                            "description": response.get("description", ""),
                            "schema": response.get("content", {}).get("application/json", {}).get("schema", {})
                        }
                    
                    contract["routes"].append(route_info)
        
        # Extract models from components
        schemas = openapi_schema.get("components", {}).get("schemas", {})
        for name, schema in schemas.items():
            model_info = {
                "name": name,
                "fields": {}
            }
            
            properties = schema.get("properties", {})
            for field_name, field_schema in properties.items():
                model_info["fields"][field_name] = {
                    "type": field_schema.get("type", "unknown"),
                    "required": field_name in schema.get("required", []),
                    "description": field_schema.get("description", "")
                }
            
            contract["models"].append(model_info)
        
        # Write contract
        with open(contract_path, "w") as f:
            json.dump(contract, f, indent=2, default=str)
        
        logger.info(f"API contract emitted to {contract_path}")
        
    except Exception as e:
        logger.error(f"Failed to emit API contract: {e}")


# Include API routers
from app.api.v1.auth import router as auth_router
from app.api.v1.users import router as users_router

app.include_router(auth_router, prefix="/api/v1")
app.include_router(users_router, prefix="/api/v1")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "backend.app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG
    )
