"""Case ontology, inbox, channel, and activity models.

Revision ID: 002
Revises: 001
Create Date: 2025-01-15 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Add new columns to cases table
    op.add_column('cases', sa.Column('tenant_id', sa.String(length=100), nullable=True))
    op.add_column('cases', sa.Column('inbox_item_id', sa.Integer(), nullable=True))
    op.add_column('cases', sa.Column('assigned_to', sa.Integer(), nullable=True))
    op.add_column('cases', sa.Column('ontology', sa.JSON(), nullable=True))
    op.add_column('cases', sa.Column('ai_classification', sa.String(length=100), nullable=True))
    op.add_column('cases', sa.Column('confidence_score', sa.Float(), nullable=True))
    
    # Create foreign key for inbox_item_id
    op.create_foreign_key(
        'fk_cases_inbox_item',
        'cases', 'inbox_items',
        ['inbox_item_id'], ['id'],
        ondelete='SET NULL'
    )
    
    # Create foreign key for assigned_to (renamed from assigned_agent_id)
    op.create_foreign_key(
        'fk_cases_assigned_to',
        'cases', 'users',
        ['assigned_to'], ['id'],
        ondelete='SET NULL'
    )
    
    # Create indexes for cases
    op.create_index('ix_cases_tenant_id', 'cases', ['tenant_id'])
    op.create_index('ix_cases_inbox_item_id', 'cases', ['inbox_item_id'])
    op.create_index('ix_cases_assigned_to', 'cases', ['assigned_to'])
    
    # Drop old foreign key and column if they exist
    try:
        op.drop_constraint('cases_ibfk_1', 'cases', type_='foreignkey')
    except:
        pass
    
    try:
        op.drop_index('ix_cases_assigned_agent_id', 'cases')
    except:
        pass
    
    # Add new columns to inbox_items table
    op.add_column('inbox_items', sa.Column('channel_id', sa.Integer(), nullable=True))
    op.add_column('inbox_items', sa.Column('raw_content', sa.Text(), nullable=True))
    op.add_column('inbox_items', sa.Column('normalized_content', sa.Text(), nullable=True))
    op.add_column('inbox_items', sa.Column('attachments', sa.JSON(), nullable=True))
    op.add_column('inbox_items', sa.Column('processed_at', sa.DateTime(), nullable=True))
    op.add_column('inbox_items', sa.Column('case_id', sa.Integer(), nullable=True))
    
    # Create foreign key for channel_id
    op.create_foreign_key(
        'fk_inbox_items_channel',
        'inbox_items', 'channels',
        ['channel_id'], ['id'],
        ondelete='CASCADE'
    )
    
    # Create foreign key for case_id
    op.create_foreign_key(
        'fk_inbox_items_case',
        'inbox_items', 'cases',
        ['case_id'], ['id'],
        ondelete='SET NULL'
    )
    
    # Create indexes for inbox_items
    op.create_index('ix_inbox_items_channel_id', 'inbox_items', ['channel_id'])
    op.create_index('ix_inbox_items_case_id', 'inbox_items', ['case_id'])
    
    # Add new columns to channels table
    op.add_column('channels', sa.Column('is_active', sa.Boolean(), server_default='1', nullable=False))
    
    # Create activities table
    op.create_table(
        'activities',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('case_id', sa.Integer(), nullable=False),
        sa.Column('actor_id', sa.Integer(), nullable=True),
        sa.Column('action', sa.String(length=50), nullable=False),
        sa.Column('details', sa.JSON(), nullable=True),
        sa.Column('timestamp', sa.DateTime(), server_default=sa.text('CURRENT_TIMESTAMP'), nullable=False),
        sa.ForeignKeyConstraint(['case_id'], ['cases.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['actor_id'], ['users.id'], ondelete='SET NULL'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('ix_activities_case_id', 'activities', ['case_id'])
    op.create_index('ix_activities_actor_id', 'activities', ['actor_id'])
    op.create_index('ix_activities_timestamp', 'activities', ['timestamp'])
    op.create_index('ix_activities_action', 'activities', ['action'])


def downgrade() -> None:
    # Drop activities table
    op.drop_index('ix_activities_action', 'activities')
    op.drop_index('ix_activities_timestamp', 'activities')
    op.drop_index('ix_activities_actor_id', 'activities')
    op.drop_index('ix_activities_case_id', 'activities')
    op.drop_table('activities')
    
    # Drop inbox_items indexes and foreign keys
    op.drop_index('ix_inbox_items_case_id', 'inbox_items')
    op.drop_index('ix_inbox_items_channel_id', 'inbox_items')
    try:
        op.drop_constraint('fk_inbox_items_case', 'inbox_items', type_='foreignkey')
        op.drop_constraint('fk_inbox_items_channel', 'inbox_items', type_='foreignkey')
    except:
        pass
    op.drop_column('inbox_items', 'case_id')
    op.drop_column('inbox_items', 'processed_at')
    op.drop_column('inbox_items', 'attachments')
    op.drop_column('inbox_items', 'normalized_content')
    op.drop_column('inbox_items', 'raw_content')
    op.drop_column('inbox_items', 'channel_id')
    
    # Drop cases indexes and foreign keys
    op.drop_index('ix_cases_assigned_to', 'cases')
    op.drop_index('ix_cases_inbox_item_id', 'cases')
    op.drop_index('ix_cases_tenant_id', 'cases')
    try:
        op.drop_constraint('fk_cases_assigned_to', 'cases', type_='foreignkey')
        op.drop_constraint('fk_cases_inbox_item', 'cases', type_='foreignkey')
    except:
        pass
    op.drop_column('cases', 'confidence_score')
    op.drop_column('cases', 'ai_classification')
    op.drop_column('cases', 'ontology')
    op.drop_column('cases', 'assigned_to')
    op.drop_column('cases', 'inbox_item_id')
    op.drop_column('cases', 'tenant_id')
    
    # Drop channels columns
    op.drop_column('channels', 'is_active')
