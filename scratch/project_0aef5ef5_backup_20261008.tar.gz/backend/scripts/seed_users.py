"""Seed script to create demo users."""
import asyncio
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy.ext.asyncio import AsyncSession

from app.database import AsyncSessionLocal, init_db
from app.services.auth_service import AuthService
from app.schemas.user import UserCreate
from app.core.logging import get_logger

logger = get_logger("seed_users")


# Demo users data
DEMO_USERS = [
    {
        "email": "admin@kuoni.demo",
        "password": "admin",
        "full_name": "System Administrator",
        "role": "admin",
        "is_active": True
    },
    {
        "email": "supervisor@kuoni.demo",
        "password": "supervisor",
        "full_name": "Supervisor User",
        "role": "supervisor",
        "is_active": True
    },
    {
        "email": "agent1@kuoni.demo",
        "password": "agent",
        "full_name": "Agent One",
        "role": "agent",
        "is_active": True
    },
    {
        "email": "agent2@kuoni.demo",
        "password": "agent",
        "full_name": "Agent Two",
        "role": "agent",
        "is_active": True
    }
]


async def seed_users():
    """Seed demo users into the database."""
    logger.info("Starting user seeding...")
    
    async with AsyncSessionLocal() as db:
        for user_data in DEMO_USERS:
            try:
                # Check if user already exists
                existing = await AuthService.get_user_by_email(db, user_data["email"])
                if existing:
                    logger.info(f"User {user_data['email']} already exists, skipping...")
                    continue
                
                # Create user
                user_create = UserCreate(
                    email=user_data["email"],
                    password=user_data["password"],
                    full_name=user_data["full_name"],
                    role=user_data["role"],
                    is_active=user_data["is_active"]
                )
                
                user = await AuthService.create_user(db, user_create)
                logger.info(f"Created user: {user.email} (role: {user.role})")
                
            except Exception as e:
                logger.error(f"Failed to create user {user_data['email']}: {e}")
                raise
    
    logger.info("User seeding completed!")
    print("\n" + "="*50)
    print("Demo users created successfully!")
    print("="*50)
    for user in DEMO_USERS:
        print(f"  Email: {user['email']}")
        print(f"  Password: {user['password']}")
        print(f"  Role: {user['role']}")
        print("-"*50)


if __name__ == "__main__":
    asyncio.run(seed_users())
