#!/usr/bin/env python3
"""Seed data script for ServiceOps platform with realistic Kuoni travel industry content."""
import asyncio
import random
from datetime import datetime, timedelta
from pathlib import Path
import sys

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database import AsyncSessionLocal, init_db
from app.models.user import User
from app.models.case import Case, CaseStatus, CasePriority
from app.models.inbox_item import InboxItem, InboxStatus
from app.models.channel import Channel, ChannelType
from app.models.activity import Activity, ActionType
from app.core.security import get_password_hash


# Sample data for realistic content
FIRST_NAMES = ["Emma", "Liam", "Olivia", "Noah", "Ava", "Ethan", "Sophia", "Mason", 
               "Isabella", "William", "Mia", "James", "Charlotte", "Benjamin", "Amelia"]
LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", 
              "Davis", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez"]

DESTINATIONS = [
    "Maldives", "Seychelles", "Mauritius", "Thailand", "Bali", "Japan", "Vietnam",
    "South Africa", "Kenya", "Tanzania", "Morocco", "Egypt", "Dubai", "Oman",
    "Italy", "Greece", "Spain", "Portugal", "France", "Croatia", "Turkey",
    "Mexico", "Costa Rica", "Peru", "Argentina", "Brazil", "Caribbean"
]

ISSUE_TYPES = [
    ("Booking Issue", "Flight cancellation"),
    ("Booking Issue", "Hotel overbooking"),
    ("Refund Request", "Package cancellation"),
    ("Refund Request", "Partial refund"),
    ("Itinerary Change", "Date modification"),
    ("Itinerary Change", "Destination change"),
    ("Complaint", "Service quality"),
    ("Complaint", "Delayed response"),
    ("Inquiry", "Availability check"),
    ("Inquiry", "Pricing request"),
    ("Emergency", "Medical emergency"),
    ("Emergency", "Lost passport"),
]

EMAIL_TEMPLATES = [
    """Subject: Urgent: Flight Cancellation for Booking {booking_ref}

Dear Kuoni Team,

I am writing to inform you that my flight to {destination} scheduled for {travel_date} has been cancelled by the airline. This is extremely disappointing as this was meant to be our honeymoon trip.

Booking Reference: {booking_ref}
Passengers: {passenger_names}

We need immediate assistance with rebooking or a full refund. Please advise on the next steps.

Best regards,
{customer_name}
{customer_email}
""",
    """Subject: Request for Refund - Booking {booking_ref}

Hello,

Due to unforeseen circumstances, we need to cancel our trip to {destination}. I would like to request a full refund for our booking.

Booking Details:
- Reference: {booking_ref}
- Travel Dates: {travel_date}
- Amount Paid: £{amount}

Please confirm the refund timeline and process.

Regards,
{customer_name}
""",
    """Subject: Hotel Overbooking Issue

Dear Support,

We arrived at our hotel in {destination} only to be told they are overbooked and cannot honor our reservation. This is unacceptable after traveling for 12 hours with young children.

Booking: {booking_ref}
Original Hotel: {hotel_name}

We expect immediate alternative accommodation of equal or better standard.

{customer_name}
{customer_email}
""",
    """Subject: Change Travel Dates Request

Hi Kuoni,

We need to postpone our trip to {destination} due to a family emergency. Can you please help us change our travel dates?

Current: {travel_date}
Preferred: {new_date}
Booking: {booking_ref}

Please let us know if this is possible and any associated fees.

Thanks,
{customer_name}
""",
    """Subject: Complaint About Service Quality

To Whom It May Concern,

I am extremely disappointed with the service we received during our recent trip. The transfers were delayed, the hotel was not as described, and we had to wait 3 hours at the airport.

This is not the luxury experience we paid £{amount} for. I expect compensation for these issues.

{customer_name}
Booking: {booking_ref}
""",
]

AGENT_NAMES = [
    ("Sarah Chen", "sarah.chen@kuoni.co.uk"),
    ("James Wilson", "james.wilson@kuoni.co.uk"),
    ("Maria Garcia", "maria.garcia@kuoni.co.uk"),
    ("David Thompson", "david.thompson@kuoni.co.uk"),
    ("Priya Patel", "priya.patel@kuoni.co.uk"),
]


def generate_booking_ref():
    """Generate a random booking reference."""
    return f"KU{random.randint(100000, 999999)}"


def generate_case_number():
    """Generate a case number in K-YYYY-NNNN format."""
    now = datetime.utcnow()
    counter = random.randint(1, 9999)
    return f"K-{now.year}-{counter:04d}"


def generate_customer():
    """Generate random customer data."""
    first = random.choice(FIRST_NAMES)
    last = random.choice(LAST_NAMES)
    return {
        "name": f"{first} {last}",
        "email": f"{first.lower()}.{last.lower()}@email.com",
        "phone": f"+44{random.randint(7000000000, 7999999999)}",
    }


def generate_email_content(customer, issue_type, destination):
    """Generate realistic email content."""
    template = random.choice(EMAIL_TEMPLATES)
    travel_date = (datetime.utcnow() + timedelta(days=random.randint(7, 90))).strftime("%d %B %Y")
    new_date = (datetime.utcnow() + timedelta(days=random.randint(14, 120))).strftime("%d %B %Y")
    
    return template.format(
        customer_name=customer["name"],
        customer_email=customer["email"],
        destination=destination,
        booking_ref=generate_booking_ref(),
        travel_date=travel_date,
        new_date=new_date,
        amount=random.randint(1500, 8500),
        hotel_name=f"{random.choice(['Luxury', 'Grand', 'Royal', 'Paradise'])} {random.choice(['Resort', 'Hotel', 'Villas', 'Spa'])}",
        passenger_names=f"{customer['name']} and Partner",
    )


def generate_ontology(customer, issue_type, destination, email_content):
    """Generate case ontology from content."""
    category, subcategory = issue_type
    
    sentiment_options = ["positive", "negative", "neutral", "mixed"]
    sentiment_weights = [0.1, 0.5, 0.2, 0.2] if category in ["Complaint", "Emergency"] else [0.3, 0.2, 0.3, 0.2]
    sentiment = random.choices(sentiment_options, sentiment_weights)[0]
    
    urgency_map = {
        "Emergency": "critical",
        "Complaint": "high",
        "Refund Request": "medium",
        "Booking Issue": "high",
        "Itinerary Change": "medium",
        "Inquiry": "low",
    }
    
    return {
        "customer": {
            "name": customer["name"],
            "email": customer["email"],
            "phone": customer["phone"],
            "customer_id": f"CUST{random.randint(10000, 99999)}",
            "segment": random.choice(["Premium", "Standard", "VIP"]),
            "language": "en",
        },
        "issue": {
            "category": category,
            "subcategory": subcategory,
            "description": email_content[:200] + "...",
            "booking_reference": generate_booking_ref(),
            "travel_dates": {
                "departure": (datetime.utcnow() + timedelta(days=random.randint(7, 90))).isoformat(),
                "return": (datetime.utcnow() + timedelta(days=random.randint(14, 120))).isoformat(),
            },
            "destination": destination,
        },
        "sentiment": {
            "overall": sentiment,
            "score": round(random.uniform(-0.8, 0.6), 2),
            "emotions": random.sample(["frustrated", "anxious", "disappointed", "urgent", "concerned"], 2),
        },
        "urgency": {
            "level": urgency_map.get(category, "medium"),
            "factors": random.sample(["travel_date_approaching", "payment_made", "group_size", "special_occasion"], 2),
            "deadline": (datetime.utcnow() + timedelta(days=random.randint(1, 14))).isoformat(),
        },
        "entities": [
            {"type": "destination", "value": destination, "confidence": 0.95},
            {"type": "date", "value": travel_date, "confidence": 0.88},
            {"type": "email", "value": customer["email"], "confidence": 0.99},
        ],
        "confidence_scores": {
            "category": round(random.uniform(0.75, 0.95), 2),
            "sentiment": round(random.uniform(0.70, 0.90), 2),
            "urgency": round(random.uniform(0.65, 0.85), 2),
            "entities": round(random.uniform(0.80, 0.95), 2),
            "overall": round(random.uniform(0.75, 0.92), 2),
        },
        "extracted_at": datetime.utcnow().isoformat(),
        "version": "1.0",
    }


async def create_channels(db: AsyncSession):
    """Create channel records."""
    channels = [
        Channel(
            name="Support Email",
            type=ChannelType.EMAIL,
            config={
                "host": "mail.kuoni.co.uk",
                "port": 993,
                "username": "support@kuoni.co.uk",
                "folder": "INBOX",
                "poll_interval": 300,
            },
            is_active=True,
        ),
        Channel(
            name="VIP Support Email",
            type=ChannelType.EMAIL,
            config={
                "host": "mail.kuoni.co.uk",
                "port": 993,
                "username": "vip@kuoni.co.uk",
                "folder": "INBOX",
                "poll_interval": 180,
            },
            is_active=True,
        ),
        Channel(
            name="Webhook API",
            type=ChannelType.WEBHOOK,
            config={
                "secret": "whsec_test_secret_key",
                "verify_signature": True,
                "allowed_ips": ["192.168.1.0/24"],
            },
            is_active=True,
        ),
    ]
    
    for channel in channels:
        db.add(channel)
    
    await db.commit()
    
    # Refresh to get IDs
    for channel in channels:
        await db.refresh(channel)
    
    return channels


async def create_agents(db: AsyncSession):
    """Create agent users."""
    agents = []
    for name, email in AGENT_NAMES:
        # Check if user exists
        result = await db.execute(select(User).where(User.email == email))
        existing = result.scalar_one_or_none()
        
        if not existing:
            user = User(
                email=email,
                hashed_password=get_password_hash("agent123"),
                full_name=name,
                role="agent",
                is_active=True,
                is_online=random.choice([True, False]),
            )
            db.add(user)
            agents.append(user)
        else:
            agents.append(existing)
    
    await db.commit()
    
    for agent in agents:
        await db.refresh(agent)
    
    return agents


async def create_inbox_items(db: AsyncSession, channels: list, count: int = 15):
    """Create inbox items."""
    inbox_items = []
    
    for i in range(count):
        customer = generate_customer()
        destination = random.choice(DESTINATIONS)
        issue_type = random.choice(ISSUE_TYPES)
        email_content = generate_email_content(customer, issue_type, destination)
        
        # Generate external ID
        external_id = f"MSG{datetime.utcnow().strftime('%Y%m%d%H%M%S')}{i:04d}"
        
        inbox_item = InboxItem(
            external_id=external_id,
            channel_id=random.choice(channels).id,
            raw_content=email_content,
            normalized_content=email_content.replace("\n", " ").strip(),
            attachments=[],
            received_at=datetime.utcnow() - timedelta(hours=random.randint(1, 72)),
            processed_at=None,
            status=random.choice([InboxStatus.PENDING, InboxStatus.PROCESSED]),
            case_id=None,
        )
        
        if inbox_item.status == InboxStatus.PROCESSED:
            inbox_item.processed_at = inbox_item.received_at + timedelta(minutes=random.randint(5, 60))
        
        db.add(inbox_item)
        inbox_items.append(inbox_item)
    
    await db.commit()
    
    for item in inbox_items:
        await db.refresh(item)
    
    return inbox_items


async def create_cases(db: AsyncSession, inbox_items: list, agents: list, count: int = 20):
    """Create cases from inbox items."""
    cases = []
    
    # Priority distribution
    priorities = [CasePriority.LOW] * 3 + [CasePriority.MEDIUM] * 8 + [CasePriority.HIGH] * 6 + [CasePriority.CRITICAL] * 3
    
    # Status distribution
    statuses = [CaseStatus.NEW] * 3 + [CaseStatus.ASSIGNED] * 5 + [CaseStatus.IN_PROGRESS] * 6 + [CaseStatus.PENDING] * 3 + [CaseStatus.RESOLVED] * 2 + [CaseStatus.CLOSED] * 1
    
    for i in range(count):
        # Link to inbox item if available
        inbox_item = None
        if i < len(inbox_items) and inbox_items[i].status == InboxStatus.PROCESSED:
            inbox_item = inbox_items[i]
        
        customer = generate_customer()
        destination = random.choice(DESTINATIONS)
        issue_type = random.choice(ISSUE_TYPES)
        
        # Generate email content for ontology
        email_content = generate_email_content(customer, issue_type, destination)
        ontology = generate_ontology(customer, issue_type, destination, email_content)
        
        # Determine status and assignment
        status = random.choice(statuses)
        priority = random.choice(priorities)
        assigned_to = None
        
        if status in [CaseStatus.ASSIGNED, CaseStatus.IN_PROGRESS, CaseStatus.PENDING, CaseStatus.RESOLVED, CaseStatus.CLOSED]:
            assigned_to = random.choice(agents).id
        
        # Calculate SLA based on priority
        sla_hours = {
            CasePriority.LOW: 72,
            CasePriority.MEDIUM: 24,
            CasePriority.HIGH: 8,
            CasePriority.CRITICAL: 2,
        }[priority]
        
        created_at = datetime.utcnow() - timedelta(days=random.randint(0, 30), hours=random.randint(0, 23))
        sla_deadline = created_at + timedelta(hours=sla_hours)
        
        case = Case(
            case_number=generate_case_number(),
            tenant_id="kuoni_default",
            inbox_item_id=inbox_item.id if inbox_item else None,
            status=status,
            priority=priority,
            assigned_to=assigned_to,
            ontology=ontology,
            ai_classification=issue_type[0],
            confidence_score=ontology["confidence_scores"]["overall"],
            sla_deadline=sla_deadline,
            created_at=created_at,
            updated_at=created_at + timedelta(hours=random.randint(1, 48)),
        )
        
        db.add(case)
        cases.append(case)
        
        # Update inbox item if linked
        if inbox_item:
            inbox_item.case_id = case.id
    
    await db.commit()
    
    for case in cases:
        await db.refresh(case)
    
    return cases


async def create_activities(db: AsyncSession, cases: list, agents: list):
    """Create activity logs for cases."""
    activities = []
    
    for case in cases:
        # Always create a CREATED activity
        activity = Activity(
            case_id=case.id,
            actor_id=None,
            action=ActionType.CREATED,
            details={
                "source": "inbox_item" if case.inbox_item_id else "manual",
                "inbox_item_id": case.inbox_item_id,
            },
            timestamp=case.created_at,
        )
        db.add(activity)
        activities.append(activity)
        
        # Add ASSIGNED activity if assigned
        if case.assigned_to:
            activity = Activity(
                case_id=case.id,
                actor_id=case.assigned_to,
                action=ActionType.ASSIGNED,
                details={
                    "previous_assignee": None,
                    "new_assignee": case.assigned_to,
                    "reason": "Auto-assigned based on workload",
                },
                timestamp=case.created_at + timedelta(minutes=random.randint(5, 30)),
            )
            db.add(activity)
            activities.append(activity)
        
        # Add status change activities
        if case.status in [CaseStatus.IN_PROGRESS, CaseStatus.PENDING]:
            activity = Activity(
                case_id=case.id,
                actor_id=case.assigned_to,
                action=ActionType.STATUS_CHANGED,
                details={
                    "previous_status": CaseStatus.ASSIGNED.value if case.assigned_to else CaseStatus.NEW.value,
                    "new_status": case.status.value,
                    "reason": "Agent updated status",
                },
                timestamp=case.updated_at - timedelta(hours=random.randint(1, 12)),
            )
            db.add(activity)
            activities.append(activity)
        
        # Add ontology update for some cases
        if random.random() > 0.3:
            activity = Activity(
                case_id=case.id,
                actor_id=None,
                action=ActionType.ONTOLOGY_UPDATED,
                details={
                    "overwrite": False,
                    "ontology_version": "1.0",
                },
                timestamp=case.created_at + timedelta(minutes=random.randint(10, 60)),
            )
            db.add(activity)
            activities.append(activity)
    
    await db.commit()
    
    return activities


async def seed_data():
    """Main seed function."""
    print("🌱 Starting data seeding...")
    
    async with AsyncSessionLocal() as db:
        print("📧 Creating channels...")
        channels = await create_channels(db)
        print(f"   ✓ Created {len(channels)} channels")
        
        print("👤 Creating agents...")
        agents = await create_agents(db)
        print(f"   ✓ Created {len(agents)} agents")
        
        print("📨 Creating inbox items...")
        inbox_items = await create_inbox_items(db, channels, count=15)
        print(f"   ✓ Created {len(inbox_items)} inbox items")
        
        print("📁 Creating cases...")
        cases = await create_cases(db, inbox_items, agents, count=20)
        print(f"   ✓ Created {len(cases)} cases")
        
        print("📝 Creating activity logs...")
        activities = await create_activities(db, cases, agents)
        print(f"   ✓ Created {len(activities)} activities")
        
        print("\n✅ Seeding complete!")
        print(f"\nSummary:")
        print(f"  - Channels: {len(channels)}")
        print(f"  - Agents: {len(agents)}")
        print(f"  - Inbox Items: {len(inbox_items)}")
        print(f"  - Cases: {len(cases)}")
        print(f"  - Activities: {len(activities)}")
        print(f"\nDefault agent credentials:")
        print(f"  Email: {agents[0].email}")
        print(f"  Password: agent123")


if __name__ == "__main__":
    asyncio.run(seed_data())
